﻿using System;
using System.Reflection;
using UnityEditor;

namespace Unity.Microsoft.GDK.Tools.Xbox.Editor
{
    /// <summary>
    /// Provides helper methods for Xbox platform.
    /// </summary>
    internal static class XboxPlatformHelpers
    {
        private static readonly Lazy<Type> s_GameCoreUtilsType = new(() =>
            Type.GetType("UnityEditor.GameCore.GameCoreUtils, UnityEditor.GameCoreCommon.Extensions"));

        private static readonly Lazy<MethodInfo> s_GdkEditionMethod = new(() =>
            s_GameCoreUtilsType.Value?.GetMethod("GetRequiredGdkEdition",
                BindingFlags.Public | BindingFlags.Static));

        /// <summary>
        /// Gets the required GDK version for the specified build target.
        /// </summary>
        /// <param name="platform">The build target platform.</param>
        /// <returns>The required GDK version, or -1 if not available.</returns>
        public static int GetRequiredGdkVersion(BuildTarget platform)
        {
            try
            {
                var edition = (int)(s_GdkEditionMethod.Value?.Invoke(null, new object[] { platform }) ?? -1);
                return edition;
            }
            catch (Exception)
            {
                return -1;
            }
        }
    }
}