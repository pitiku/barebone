using System.Text;
using System.Xml;
using UnityEditor;
#if UNITY_GAMECORE
using UnityEditor.GameCore;
#endif 
using UnityEngine;

namespace Unity.Microsoft.GDK.Tools.Xbox.Editor
{
#if UNITY_GAMECORE
#if UNITY_6000_5_OR_NEWER
#if EXPERIMENTAL_LAYOUT_HANDLING
    internal class XboxPackageLayoutProcessor : UnityEditor.GameCore.IProcessMakePkgPackageLayout
    {
        /// <summary>
        /// Defines the execution order of this callback. Callbacks with lower numbers are executed first.
        /// </summary>
        public int callbackOrder => 1000;

        /// <summary>
        /// Callback method to update the package mapping XML. Raises the GdkToolsEvents.OnUpdatePackageMapping event.
        /// </summary>
        /// <param name="mappingDocument">The XML document representing the layout file.</param>
        /// <param name="looseContentPath">The full path to the loose content directory.</param>
        public void OnProcessPackageLayout(XmlDocument mappingDocument, string looseContentPath)
        {
            Debug.Log($"[GDK Tools for Xbox] OnProcessPackageLayout. Loose content path: {looseContentPath}");

            Unity.Microsoft.GDK.Tools.Editor.GdkToolsEvents.RaiseUpdatePackageMapping(mappingDocument, looseContentPath, EditorUserBuildSettings.activeBuildTarget);
        }
    }
#endif
#endif
#endif
}