using System.IO;
using Unity.Microsoft.GDK.Tools.Editor;
using UnityEditor;
using UnityEngine;

namespace Unity.Microsoft.GDK.Tools.Xbox.Editor
{
    [InitializeOnLoad]
    internal class XboxSeriesPlatform : GdkPlatform
    {
        public override string DisplayName => "Xbox Series X|S";
        public override GUIContent TabTitle => k_TabTitle;
        public override uint TabOrder => 300;
        public override BuildTarget BuildTarget => BuildTarget.GameCoreXboxSeries;
        public override RuntimePlatform RuntimePlatform => RuntimePlatform.GameCoreXboxSeries;
        public override string PlatformCompilerConditional => "UNITY_GAMECORE_XBOXSERIES";

        private static readonly Texture2D k_Image = SelectTabImage();
        private static readonly GUIContent k_TabTitle = EditorGUIUtility.TrTextContent("Xbox Series X|S", "Xbox Series X|S settings", k_Image);

        internal static Texture2D SelectTabImage()
        {
            if (EditorGUIUtility.isProSkin)
            {
                // Dark theme
                return AssetDatabase.LoadAssetAtPath<Texture2D>("Packages/com.unity.microsoft.gdk.tools.xbox/Editor/Images/Dark/Xbox Series.png");
            }

            //Light theme
            return AssetDatabase.LoadAssetAtPath<Texture2D>("Packages/com.unity.microsoft.gdk.tools.xbox/Editor/Images/Light/Xbox Series.png");
        }

        static XboxSeriesPlatform()
        {
            var platform = new XboxSeriesPlatform
            {
                PlatformBuilder = new XboxPlatformBuilder(ST_DeviceFamily.Scarlett)
            };

            GDKPlatformManager.RegisterGdkPlatform(platform);
        }

        public override bool SupportsBuildTarget(BuildTarget buildTarget)
        {
            return buildTarget == BuildTarget;
        }

        public override bool SupportsBuildTargetGroup(BuildTargetGroup buildTargetGroup)
        {
            return buildTargetGroup == BuildPipeline.GetBuildTargetGroup(BuildTarget);
        }

        public override int SelectedGdkEdition
        {
            get => XboxPlatformHelpers.GetRequiredGdkVersion(BuildTarget.GameCoreXboxSeries);
            set { }
        }
    }
}