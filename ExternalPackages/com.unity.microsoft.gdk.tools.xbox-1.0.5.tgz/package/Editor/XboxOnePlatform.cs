using System.IO;
using Unity.Microsoft.GDK.Tools.Editor;
using UnityEditor;
using UnityEngine;

namespace Unity.Microsoft.GDK.Tools.Xbox.Editor
{
    [InitializeOnLoad]
    internal class XboxOnePlatform : GdkPlatform
    {
        public override string DisplayName => "Xbox One";
        public override GUIContent TabTitle => k_TabTitle;
        public override uint TabOrder => 200;
        public override BuildTarget BuildTarget => BuildTarget.GameCoreXboxOne;
        public override RuntimePlatform RuntimePlatform => RuntimePlatform.GameCoreXboxOne;
        public override string PlatformCompilerConditional => "UNITY_GAMECORE_XBOXONE";

        private static readonly Texture2D k_Image = SelectTabImage();
        private static readonly GUIContent k_TabTitle = EditorGUIUtility.TrTextContent("Xbox One", "Xbox One settings", k_Image);

        internal static Texture2D SelectTabImage()
        {
            if (EditorGUIUtility.isProSkin)
            {
                // Dark theme
                return AssetDatabase.LoadAssetAtPath<Texture2D>("Packages/com.unity.microsoft.gdk.tools.xbox/Editor/Images/Dark/Xbox One.png");
            }

            //Light theme
            return AssetDatabase.LoadAssetAtPath<Texture2D>("Packages/com.unity.microsoft.gdk.tools.xbox/Editor/Images/Light/Xbox One.png");
        }
        static XboxOnePlatform()
        {
            var platform = new XboxOnePlatform
            {
                PlatformBuilder = new XboxPlatformBuilder(ST_DeviceFamily.XboxOne)
            };

            GDKPlatformManager.RegisterGdkPlatform(platform);
        }

        public override bool SupportsBuildTarget(BuildTarget buildTarget)
        {
            return buildTarget == BuildTarget;
        }

        public override bool SupportsBuildTargetGroup(BuildTargetGroup buildTargetGroup)
        {
            return buildTargetGroup == BuildPipeline.GetBuildTargetGroup(BuildTarget);
        }

        public override int SelectedGdkEdition
        {
            get => XboxPlatformHelpers.GetRequiredGdkVersion(BuildTarget.GameCoreXboxOne);
            set { }
        }
    }
}