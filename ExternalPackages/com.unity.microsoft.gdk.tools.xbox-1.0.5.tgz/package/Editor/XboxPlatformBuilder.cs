using System;
using System.IO;
using System.Linq;
using Unity.Microsoft.GDK.Tools.Editor;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;

#if UNITY_GAMECORE
using UnityEditor.GameCore;
#endif

using UnityEngine;

namespace Unity.Microsoft.GDK.Tools.Xbox.Editor
{
    internal class XboxPlatformBuilder : GdkPlatform.IBuilder
    {
        private static (string, string)[] _StagedShellVisualsImageSourceDestPaths = null;

        private ST_DeviceFamily _TargetDeviceFamilyField;

        public XboxPlatformBuilder(ST_DeviceFamily targetDeviceFamilyField)
        {
            _TargetDeviceFamilyField = targetDeviceFamilyField;
        }

        public void OnPreprocessBuild(BuildReport report, GdkSettingsAsset.PlatformGdkSettings platformGdkSettings)
        {
            // We only care if this platform is configured to target Microsoft GDK
            if (platformGdkSettings is { targetMicrosoftGdk: false })
                return;

            // Your custom actions or modifications before the build process starts ...
            string stagingArea = Path.Combine("Temp", "StagingArea");
            string stagingAreaData = Path.Combine(stagingArea, "Data");;

            // A GDK build requires a Microsoft Game Config to live alongside the built executable
            // we won't be able to complete the build if we can't locate one (missing or not configured)
            string mgcAssetPath = AssetDatabase.GetAssetPath(platformGdkSettings.gameConfigAsset);
            if (string.IsNullOrEmpty(mgcAssetPath))
            {
                Debug.LogError("Build FAILED: Targeting Microsoft GDK but a Microsoft Game Config has not been configured for this platform.");
                throw new BuildFailedException("Build failure: " + report.summary.result);
            }

            CreateManifest(report, mgcAssetPath, stagingArea);
        }

        public void OnPostprocessBuild(BuildReport report, GdkSettingsAsset.PlatformGdkSettings platformGdkSettings)
        {
            // NOTE: OnPostprocessBuild is called AFTER the platform extension PostProcess this means the
            // built executable is likely already deployed and running!
        }

        private bool CreateManifest(BuildReport report, string mgcAssetPath, string stagingArea)
        {
#if UNITY_GAMECORE
            Game xmlGameConfig = GameConfigAsset.LoadAsXmlGameConfig(mgcAssetPath);

#if UNITY_GAMECORE_XBOXONE
            GameCoreXboxOneSettings gamecoreSettings = GameCoreXboxOneSettings.GetInstance();
#elif UNITY_GAMECORE_SCARLETT
            GameCoreScarlettSettings gamecoreSettings = GameCoreScarlettSettings.GetInstance();
#endif

            // As we are taking ownership of the MicrosoftGame.config creation, we must be sure to include
            // any additions the Game Core platform extension would have included
            var overrideIsDevOnly =
                gamecoreSettings.DeploymentMethod == GameCoreDeployMethod.Package
                && gamecoreSettings.BuildSubtarget != GameCoreBuildSubtarget.Master;

            // We need to make sure that the 'Executable Name' is correctly configured in the MGC is correct!
            CT_ExecutableList newExecutableList = new CT_ExecutableList();
            CT_ExecutableListExecutable newExecutable = new CT_ExecutableListExecutable();

            string targetExecutableName = GameCoreUtils.GenerateExecutableName(PlayerSettings.productName,
                xmlGameConfig.TitleId ?? "",
                VariationExeFor(EditorUserBuildSettings.activeBuildTarget, gamecoreSettings.BuildSubtarget),
                (report.summary.options & BuildOptions.InstallInBuildFolder) != 0);

            newExecutable.Name = targetExecutableName;

            newExecutable.TargetDeviceFamily = _TargetDeviceFamilyField;
            newExecutable.TargetDeviceFamilySpecified = true;

            newExecutable.Id = "Game";
            newExecutable.IsDevOnly = !overrideIsDevOnly;

            newExecutableList.Executable = new[] { newExecutable };

            xmlGameConfig.ExecutableList = newExecutableList;

            // ensure the debug ports are opened if any of these options are set
            if ( EditorUserBuildSettings.development
                 || EditorUserBuildSettings.allowDebugging
                 || EditorUserBuildSettings.connectProfiler
                 || EditorUserBuildSettings.waitForPlayerConnection
                 || EditorUserBuildSettings.waitForManagedDebugger)
            {
                if ( xmlGameConfig.DevelopmentOnly == null )
                    xmlGameConfig.DevelopmentOnly = new CT_DevelopmentOnly();

                if ( xmlGameConfig.DevelopmentOnly.DebugNetworkPortList == null )
                    xmlGameConfig.DevelopmentOnly.DebugNetworkPortList = new CT_DebugNetworkPortList();

                if (xmlGameConfig.DevelopmentOnly.DebugNetworkPortList.DebugNetworkPort == null)
                {
                    xmlGameConfig.DevelopmentOnly.DebugNetworkPortList.DebugNetworkPort = new string[] { "4600", "4601" };
                }
                else
                {
                    // make sure the two debug ports exist in the array
                    xmlGameConfig.DevelopmentOnly.DebugNetworkPortList.DebugNetworkPort =
                        xmlGameConfig.DevelopmentOnly.DebugNetworkPortList.DebugNetworkPort.Union(
                            new string[] { "4600", "4601" }).ToArray<string>();
                }
            }

            if (gamecoreSettings.DeploymentMethod == GameCoreDeployMethod.Package)
            {
                if ( xmlGameConfig.DevelopmentOnly != null )
                {
                    xmlGameConfig.DevelopmentOnly.ContentIdOverride = null;
                    xmlGameConfig.DevelopmentOnly.EKBIDOverride = null;
                }
            }

            // Save the updated MGC but don't touch the original asset (for now anyways)
            GameConfigAsset.SaveXmlGameConfig(Path.Combine(stagingArea, "MicrosoftGame.config"), xmlGameConfig);

            return true;
#else
            return false;
#endif
        }

#if UNITY_GAMECORE
        private static string VariationExeFor(BuildTarget target, GameCoreBuildSubtarget subtarget)
        {
            switch (subtarget)
            {
                case GameCoreBuildSubtarget.Development:
                    return $"{target}Player_Release.exe";
                case GameCoreBuildSubtarget.Master:
                    return $"{target}PlayerNoDevelopment_Master.exe";
                case GameCoreBuildSubtarget.Debug:
                    return $"{target}Player_Debug.exe";
            }

            return "";
        }
#endif

        public string GetLocalizationOutputPath(BuildReport report)
        {
            return Path.Combine("Temp", "StagingArea");
        }

        [Obsolete("Please use GetLocalizationOutputPath(BuildReport report) instead", false)]
        public string GetLocalizationOutputPath()
        {
            return Path.Combine("Temp", "StagingArea");
        }

        public string GetStagedResourcePriPath()
        {
            var stagedResourcesPriPath = Path.GetFullPath(Path.Combine("Temp", "StagingArea", "Resources.pri"));
            if (File.Exists(stagedResourcesPriPath))
                return stagedResourcesPriPath;

            return "";
        }

        public void SetStagedShellVisualsImageSourceDestPaths((string, string)[] stagedShellVisualsImageSourceDestPaths)
        {
            _StagedShellVisualsImageSourceDestPaths = stagedShellVisualsImageSourceDestPaths;
        }

        public (string, string)[] GetStagedShellVisualsImageSourceDestPaths()
        {
            return _StagedShellVisualsImageSourceDestPaths;
        }
    }
}