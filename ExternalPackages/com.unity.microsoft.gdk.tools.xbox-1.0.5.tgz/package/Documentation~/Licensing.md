# Licensing

Refer to the following files included with the package:

* LICENSE.md
