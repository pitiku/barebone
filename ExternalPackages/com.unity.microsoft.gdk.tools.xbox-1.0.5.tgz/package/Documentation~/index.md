# Microsoft GDK Tools for Xbox

This package extends the **Microsoft GDK Tools** package adding support for the Xbox One and Xbox Series platforms. By adding this package to your project, along with the **Microsoft GDK Tools** package, you will be able to use the same GDK workflow for both Xbox and Windows platforms.

This package is provided by Unity and co-developed in partnership with the Microsoft Corporation.

> [!NOTE]
> The Microsoft GDK Tools for Xbox package is supported only on Unity Editor for Windows.

## Installation

To install this package, follow the instructions in the [Package Manager documentation](https://docs.unity3d.com/Manual/Packages.html).

## Requirements

- Unity Editor 2022.3 for Windows and later (recommended)
- This package depends on:
  - com.unity.microsoft.gdk.tools

## Features

This package provides:

* Shared workflow for Xbox One platform
* Shared workflow for Xbox Series platform

## Support

Refer to: [Support](Support.md)

## Licensing

Refer to: [Licensing](Licensing.md)