# Microsoft GDK Tools for Xbox: Support

The 'Microsoft GDK Tools for Xbox' package provides a common GDK workflow for the Xbox One and Xbox Series platforms. The first port of call for help is the documentation supplied with this package and with the Microsoft GDK Tools package.
