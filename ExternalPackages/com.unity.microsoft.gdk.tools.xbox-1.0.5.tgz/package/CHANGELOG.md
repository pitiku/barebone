# Changelog
All notable changes to this package will be documented in this file (reverse chronological order).

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/) and this project adheres
 to [Semantic Versioning](http://semver.org/spec/v2.0.0.html) expressed as MAJOR.MINOR.PATCH:

- Different MAJOR: there is at least one breaking change, and neither version of the package can be substituted for the other. For example, versions 1.2.3 and 2.0.0 are not compatible and cannot be used interchangeably.
- Same MAJOR, different MINOR: the highest MINOR introduces functionality in a backward-compatible way. For example, version 1.3.0 can be used to fulfill a dependency on 1.2.0 because 1.3.0 is backward-compatible; however because it introduces new features, the reverse is not true.
- Same MAJOR.MINOR, different PATCH: the highest PATCH introduces bug fixes without changing the API at all, in a backward-compatible way. For example, versions 1.3.0 and 1.3.1 should be interchangeable as they have the same API, although 1.3.1 contains a bug fix not present in 1.3.0.

## [1.0.5] - 2026-02-01
### Changed
- Changed min supported Unity editor version to: 2022.3.
### Fixed
- Script build errors relating to available platforms. 

## [1.0.4] - 2025-07-01
### Added
- Added the ability to see the required GDK Edition on the GDK Settings tab pages for Xbox platforms where supported.

### Fixed
- Updated the minimum version requirement on the com.unity.microsoft.gdk.tools package to 1.4.4


## [1.0.2] - 2024-09-09
### Changed
- Update `XboxPlatformBuilder` due to change in base class.


## [1.0.1] - 2024-06-17
### Changed
- Bumped patch version as package dependancy has been updated.


## [1.0.0] - 2024-03-28
### Fixed
- Platform tabs on `Microsoft GDK - Project Settings` window maintains predictable order.

### Changed
- Bump package version


## [1.0.0-pre.3] - 2024-03-18
### Changed
- Bumped version to keep inline with other related packages
- Revised documentation


## [0.2.0] - 2024-02-06
### Changed
- Bumped version to keep inline with other related packages


## [0.1.0] - 2024-01-31
### Added
- Initial workflow support for the Xbox One and Xbox Series platforms


#### This is the first release of *Unity Package com.unity.microsoft.gdk.tools*.

*Initial release.*