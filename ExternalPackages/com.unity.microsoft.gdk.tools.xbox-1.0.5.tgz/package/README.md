# com.unity.microsoft.gdk.tools.xbox

**Package Status: Supported**

This package extends the _Microsoft GDK Tools_ package adding support for the Xbox One and Xbox Series platforms. By adding this package to your project along with the _Microsoft GDK Tools package_ you will be able to use the same GDK workflow for both Xbox and Windows platforms.

This package is provided by Unity and co-developed in partnership with the Microsoft Corporation.

## Compatibility

It is always recommended to use the latest version of the editor stream you have selected. The following is the lowest editor versions expected to work:

- Unity 6000.2 (6000.2.0a7)
- Unity 6000.1 (6000.1.0a10)
- Unity 6000.0 (6000.0.42f1)
- Unity 2022.3 (2022.3.60f1)

## Documentation

Package documentation is included in the `Documentation~` folder (hidden in the editor).

## Roadmap

...

## See Also

- LICENSE.md, for general package licensing
- CHANGELOG.md, for package develoment history
