#if UNITY_EDITOR_WIN
using System;
using System.Diagnostics;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using Sony.PS5.Dialog;
using UnityEditor.UnityLinker;
using UnityEngine;

internal class BuildPackageLibs : IPreprocessBuildWithReport, IMovePRXCallback
{
    public int callbackOrder => 0;

    static string PackageName => "com.unity.commondialog.ps5";
    static string SourcePath => $"Packages/{PackageName}/Source~";
    const int k_PRXBuildTimeOutS = 600; //10 minutes is the max time allowed to build the PRX

    readonly string[] m_CompileAgainstLibs = new string[]
    {
        "SceMsgDialog_stub_weak",
        "SceSigninDialog_stub_weak",
        "SceErrorDialog_stub_weak",
        "SceImeDialog_stub_weak",
        "SceSysmodule_stub_weak",
        "SceUserService_stub_weak",
        "SceWebBrowserDialog_stub_weak",
        "SceVrSetupDialog_stub_weak"
    };


    public void OnPreprocessBuild(BuildReport report)
    {
        var buildTarget = report.summary.platform;
        if (!IsBuildTargetValid(buildTarget))
        {
            return;
        }

        string prxPath = GetPRXBuildLocation(buildTarget);
        string prxDir = Path.GetDirectoryName(prxPath);

        if (IsPRXRebuildRequired(prxPath))
        {
            if (!Directory.Exists(prxDir))
            {
                if (string.IsNullOrWhiteSpace(prxDir))
                {
                    throw new BuildFailedException("No PRX Directory");
                }
                Directory.CreateDirectory(prxDir);
            }

            BuildPackagePRX(buildTarget, prxPath, m_CompileAgainstLibs);
        }
    }

    public void MovePRXToBuildLocation(BuildTarget target, string buildOutputLocation, bool developmentBuild)
    {
        if (!IsBuildTargetValid(target))
        {
            return;
        }

        string projectDir = Application.dataPath.Replace("/Assets", "");
        string stagingArea = BuildUtils.GetStagingAreaLocationFor(target, projectDir, buildOutputLocation);
        CopyLibraryPRXToStagingArea(GetPRXBuildLocation(target), stagingArea);
    }

    static bool IsPRXRebuildRequired(string prxPath)
    {
        // The PRX should be (re)built if either of the following conditions are met:

        // 1: If it does not yet exist (e.g. fresh clone of project from source control, user deleted Library/, etc.)
        var prxInfo = new FileInfo(prxPath);
        if (!prxInfo.Exists)
        {
            Console.WriteLine($"Building PRX at {prxPath}, since it does not already exist.");
            return true;
        }

        // 2: If any of the source files or directories are newer than the PRX.
        //
        //    This could be due to local edits by the user or due to an updated package .tgz file being used (e.g. version upgrade).
        //
        //    Note that FILES (e.g. *.cpp) that came from a decompressed .tgz retain their original timestamps from the .tgz,
        //    but DIRECTORIES are created as required during decompression and will have a recent timestamp.
        var sourceDirInfo = new DirectoryInfo(SourcePath);
        IEnumerable<FileSystemInfo> sourceFilesAndDirs = sourceDirInfo.EnumerateFileSystemInfos("*", SearchOption.AllDirectories);
        sourceFilesAndDirs = sourceFilesAndDirs.Append(sourceDirInfo); // Include the Source~ directory itself.
        IEnumerable<FileSystemInfo> newer = sourceFilesAndDirs.Where(x => x.LastWriteTime > prxInfo.LastAccessTime);
        bool anyNewer = newer.Any();
        if (anyNewer)
        {
            Console.WriteLine($"Rebuilding existing PRX at {prxInfo.FullName} because it is older ({prxInfo.LastWriteTime}) than the following filesystem entries: {string.Join(", ", newer.Select(x => $"{x.FullName} ({x.LastWriteTime})"))}.");
            return true;
        }

        // If we get here then the PRX already exists and is more recent than any of its sources.
        Console.WriteLine($"PRX at {prxInfo.FullName} exists and is more recent than any of its sources under {sourceDirInfo.FullName}.  No need to rebuild.");
        return false;
    }

    static void BuildPackagePRX(BuildTarget target, string outputPath, string[] compileAgainstLibs)
    {
        string sdkLoc = Environment.GetEnvironmentVariable(SDKUtils.GetSdkEnvVarFor(target));
        string clangLoc = $"{sdkLoc}/host_tools/bin/{SDKUtils.GetClangFor(target)}";

        string allSourcePaths = string.Empty;
        string[] allDirs = Directory.GetDirectories(SourcePath, "*", SearchOption.AllDirectories);

        //Include the base folder also, if it has cpp files in it
        if (Directory.GetFiles(SourcePath, "*.cpp").Length > 0)
        {
            allSourcePaths += $"\"{Path.GetFullPath(Path.Combine(SourcePath, "*.cpp"))}\" ";
        }

        foreach (var dir in allDirs)
        {
            if (Directory.GetFiles(dir, "*.cpp").Length == 0)
            {
                continue;
            }
            allSourcePaths += $"\"{Path.GetFullPath(Path.Combine(dir, "*.cpp"))}\" ";
        }

        string allLinkLibs = string.Empty;
        foreach (var lib in compileAgainstLibs)
        {
            allLinkLibs += $"-l {lib} ";
        }

        string command = $"-o\"{outputPath}\" {allSourcePaths} -g -D GLOBAL_EVENT_QUEUE -D LIBRARY_IMPL -O3 -I Includes --shared {allLinkLibs}";

        ProcessStartInfo startInfo = new ProcessStartInfo(clangLoc, command)
        {
            CreateNoWindow = true,
            UseShellExecute = false,
            RedirectStandardError = true,
        };

        Console.WriteLine($"Building PRX with {clangLoc} {command}");
        Process proc = Process.Start(startInfo);
        string errorOutput = proc.StandardError.ReadToEnd();
        proc.WaitForExit(k_PRXBuildTimeOutS);
        if (!proc.HasExited)
        {
            proc.Kill();
            throw new BuildFailedException($"PRX Build Timed Out\n{errorOutput}");
        }

        if (proc.ExitCode != 0)
        {
            throw new BuildFailedException(errorOutput);
        }
    }

    static void CopyLibraryPRXToStagingArea(string prxLocation, string stagingArea)
    {
        string copyPath = Path.Combine(stagingArea, LibraryInfo.LibraryNameWithExtension);
        if (!Directory.Exists(stagingArea))
        {
            Directory.CreateDirectory(stagingArea);
        }

        File.Copy(prxLocation, copyPath, true);
    }

    static string GetPRXBuildLocation(BuildTarget target)
    {
        //Example Path: Library/SourceGeneratedPlugins/PS5/7000045/CommonDialog.prx
        string relativePath = Path.Combine("Library", "SourceGeneratedPlugins", target.ToString(),
            SDKUtils.GetSDKVersionString(target), $"{LibraryInfo.LibraryNameWithExtension}");
        return Path.GetFullPath(relativePath);
    }

    static bool IsBuildTargetValid(BuildTarget target)
    {
        return target is BuildTarget.PS5;
    }
}

internal interface IMovePRXCallback : IUnityLinkerProcessor
{
    string IUnityLinkerProcessor.GenerateAdditionalLinkXmlFile(BuildReport report, UnityLinkerBuildPipelineData data)
    {
        //In 2021.3 report can return null for non-playstation platforms
        if (report == null)
        {
            return string.Empty;
        }

        MovePRXToBuildLocation(report.summary.platform, report.summary.outputPath, report.summary.options.HasFlag(BuildOptions.Development));
        return string.Empty;
    }

    public void MovePRXToBuildLocation(BuildTarget target, string buildOutputLocation, bool developmentBuild);
}
#endif
