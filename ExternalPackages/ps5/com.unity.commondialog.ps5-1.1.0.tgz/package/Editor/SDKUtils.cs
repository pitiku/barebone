#if UNITY_EDITOR_WIN
using System;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;

internal static class SDKUtils
{
    internal static string GetSDKVersionString(BuildTarget target)
    {
        string verstring = string.Empty;
        string sdkPath = System.Environment.GetEnvironmentVariable(GetSdkEnvVarFor(target));
        if (sdkPath != null)
        {
            string versionFile = Path.Combine(sdkPath, "target/include/sdk_version.h");
            if (File.Exists(versionFile))
            {
                string[] lines = File.ReadAllLines(versionFile);
                foreach (string line in lines)
                {
                    //Extract the value following #define SCE_PROSPERO_SDK_VERSION
                    string regexPattern = $@"#define\s+{GetSdkVersionStringFor(target)}\s+\(\s*0x([0-9a-fA-F]+)u\s*\)";
                    Match match = Regex.Match(line, regexPattern);
                    if (match.Success)
                    {
                        verstring = match.Groups[1].Value;
                    }
                }
            }
        }

        return verstring;
    }

    internal static string GetSdkEnvVarFor(BuildTarget target)
    {
        if (target == BuildTarget.PS5)
            return "SCE_PROSPERO_SDK_DIR";
        throw new InvalidOperationException($"Cannot get env var for {target}");
    }

    internal static string GetClangFor(BuildTarget target)
    {
        if (target == BuildTarget.PS5)
            return "prospero-clang.exe";
        throw new InvalidOperationException($"Cannot get clang for {target}");
    }

    static string GetSdkVersionStringFor(BuildTarget target)
    {
        if (target == BuildTarget.PS5)
            return "SCE_PROSPERO_SDK_VERSION";
        throw new InvalidOperationException($"Cannot get SDK for {target}");
    }
}
#endif
