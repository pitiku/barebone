using UnityEngine;
using UnityEditor;
using System.IO;
using System;
using System.Collections.Generic;


public class SetCommonDialogPlatformOptionsPS5
{
#if UNITY_PS5
    //Method to do work
    static string SearchForFile(string path, string findFilename, bool returnAssetRelativePath = false)
    {
        string findFilenameNoExt = Path.GetFileNameWithoutExtension(findFilename);

        var files = Directory.EnumerateFiles(path, "*.*", SearchOption.AllDirectories);
        foreach (var file in files)
        {
            if (Path.GetFileNameWithoutExtension(file) == findFilenameNoExt)
            {
                if(returnAssetRelativePath)
                {
                    return file.Replace(Application.dataPath, "Assets");
                }
                return file;
            }
        };

        return "";
    }

    static string SearchForDirectory(string path, string findDirectory, bool returnAssetRelativePath = false)
    {
        var directories = Directory.EnumerateDirectories(path, "*", SearchOption.AllDirectories);
        foreach (var directory in directories)
        {
            string fullPath = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar);
            string lastDirName = Path.GetFileName(fullPath);

            if (lastDirName.ToLower() == findDirectory.ToLower())
            {
                if (returnAssetRelativePath)
                {
                    return directory.Replace(Application.dataPath, "Assets");
                }
                return directory;
            }
        };

        return "";
    }


    // Replace whatever Input Manager you currently have
    [MenuItem("PS5 Samples/CommonDialog/Set Input Manager")]
    static void ReplaceInputManager()
    {

        // This is the InputManager asset that comes with the example project. Note that to avoid an import error, the '.asset' file extension has been removed
        string sourceFile = SearchForFile(Application.dataPath, "InputManager");

        // This is the InputManager in your ProjectSettings folder
        string targetFile = Application.dataPath;
        targetFile = targetFile.Replace("/Assets", "/ProjectSettings/InputManager.asset");

        // Replace the ProjectSettings file with the new one, and trigger a refresh so the Editor sees it
        FileUtil.ReplaceFile(sourceFile, targetFile);
        AssetDatabase.Refresh();



        Debug.Log("InputManager replaced! " + sourceFile + " -> " + targetFile);
    }
#endif
    }
