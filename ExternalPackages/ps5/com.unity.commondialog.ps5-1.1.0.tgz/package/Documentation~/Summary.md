Provides a script API to access the PS5 Common system dialogs
