# Changelog

All notable changes to the package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).


## [1.1.0] - 2025-10-21

### Added
- Added support for URL callbacks in WebBrowserDialog. To use this specify a callbackType and callbackURL to WebBrowserParam.
- Added URL callback support to WebBrowserDialogResult. If browser has been closed from a callback the new callbackType will be set to PARAM_TYPE_URL and the new callbackURL will be set to the URL that caused the callback.
- Added DialogClose method to WebBrowserDialog to close the dialog while still wanting to get the result
- Fixed a bug that caused the native PRX to fail to recompile when upgrading to a new package .tgz.

### Changed
- EnumWebBrowserDialogResult.RESULT_USER_CANCELED is now obsolete. It is not possible for the WebBrowserDialog to be Canceled by the User. Instead RESULT_OK will be returned if the user closes the dialog.
- Updated to support SDK 12
- Signature files have been updated
- Updated XML documentation for all public APIs.

### Fixed
- WebBrowserDialogResult.result will now return the correct value based on what caused the Dialog to close: RESULT_OK, RESULT_CALLBACK or RESULT_BY_PARENTAL_CONTROL
- Fixed a bug where the WebBrowserDialog could not be re-opened if it was previously closed with Terminate

## [1.0.7] - 2025-01-10

### Fixed
- Fixed issue with Sony.PS5.Dialog.Signin.Open not setting the SigninDialogResult correctly when cancelled. 

## [1.0.6] - 2024-08-22

### Fixed
- Fixed a linker error that could occour on recent Unity versions

## [1.0.5] - 2024-04-10

### Fixed
- Fixed a null reference exception that could occur when creating a build for Windows IL2CPP in 2021.3

### Changed
   - New version of ShowUserMessage added without the infobar parameter as it does nothing on PS5. Marked old method as Obsolete. This will be removed in future releases.

## [1.0.4] - 2024-02-26

### Fixed
- Fixed a infinite build loop that could occur when an error was thrown during serialization (e.g shader compilation)

## [1.0.3] - 2024-01-10

### Fixed
   - Fixed an issue where the pacakge would invalidate the PackageCache when building and the package was added from a UMP Server
   - Fixed an issue where absoulte paths in the generated cpp would dirty source control when no cotents of the file has changed
   - Fixed an issue where compiling for PS5 when PS5 was not the selected platform would result in the package PRX (or cpp replacement) not being generated

### Changed
   - Instead of a pre-processed cpp source file generated in the package folder, the package now generates a prx in the Library/SoruceGeneratedPlugins folder which is added to the build

## [1.0.2] - 2023-10-25

### Fixed
   - Remove some managed code to native functions that never existed.

## [1.0.1] - 2023-10-18

### Fixed
   - Stop editor build script executing when an non-PlayStation platform is being built

## [1.0.0] - 2023-09-04
   - New package format.

## [0.0.11-preview] - 2023-07-11
   - Removed unused .meta files

## [0.0.10-preview] - 2023-04-06

### Added
   - Added support for SDK 7.0

## [0.0.9-preview] - 2022-10-19

### Added
   - Added support for SDK 6.0

## [0.0.8-preview] - 2022-09-21

### Added
   - Added support for VrSetup Dialog

## [0.0.7-preview] - 2022-05-04

### Added
   - Added support for WebBrowser Dialog
   - Added support for SDK 5.0

## [0.0.6-preview] - 2021-11-23

### Added
   - Added support for SDK 4.0

## [0.0.5-preview] - 2021-07-13

### Added
   - Added support for SDK 3.0

## [0.0.4-preview] - 2021-04-07

### Added
   - Added support for PS5 user dialogs

## [0.0.3-preview] - 2021-01-18

### Fixed
   - Updated duplicate meta files

## [0.0.2-preview] - 2021-01-01

### Added
   - Added SDK 1.0 and 2.0 prx files

## [0.0.1-preview] - 2020-12-01

### Added
   - Initial version
