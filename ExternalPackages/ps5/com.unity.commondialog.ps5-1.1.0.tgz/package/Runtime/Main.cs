using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Sony
{
	namespace PS5
	{
		namespace Dialog
		{
            /// <summary>
            /// Main dailog handling class.
            /// </summary>
			public class Main
			{
				// Initialisation.
				[DllImport(LibraryInfo.LibraryName)]
				private static extern int PrxCommonDialogInitialise();

				// House keeping.
				[DllImport(LibraryInfo.LibraryName)]
				private static extern int PrxCommonDialogUpdate();

                /// <summary>
                /// OnLog Event handlers.
                /// </summary>
				public static event Messages.EventHandler OnLog;

                /// <summary>
                /// OnLogWarning Event handlers.
                /// </summary>
				public static event Messages.EventHandler OnLogWarning;

                /// <summary>
                /// OnLogError Event handlers.
                /// </summary>
				public static event Messages.EventHandler OnLogError;

                /// <summary>
                /// Initialise the dialog system.
                /// </summary>
				public static void Initialise()
				{
					PrxCommonDialogInitialise();
				}

                /// <summary>
                /// Update the dialog system and pump messages.
                /// </summary>
				public static void Update()
				{
					PrxCommonDialogUpdate();
					PumpMessages();
				}

				static void PumpMessages()
				{
					while (Messages.HasMessage())
					{
						Messages.PluginMessage msg = new Messages.PluginMessage();
						Messages.GetFirstMessage(out msg);

						// Interpret the message and trigger corresponding events.

						Common.ProcessMessage(msg);
						Ime.ProcessMessage(msg);
						Signin.ProcessMessage(msg);
						WebBrowser.ProcessMessage(msg);
                        VrSetup.ProcessMessage(msg);

						switch (msg.type)
						{
							case Messages.MessageType.kDialog_Log:
								if (OnLog != null) OnLog(msg);
								break;

							case Messages.MessageType.kDialog_LogWarning:
								if (OnLogWarning != null) OnLogWarning(msg);
								break;

							case Messages.MessageType.kDialog_LogError:
								if (OnLogError != null) OnLogError(msg);
								break;
						}

						Messages.RemoveFirstMessage();
					}
				}
			}
		} // Dialog
	} // PS4
} // Sony
