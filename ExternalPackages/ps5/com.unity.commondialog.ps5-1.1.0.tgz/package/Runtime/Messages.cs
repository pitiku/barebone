using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Sony
{
	namespace PS5
	{
		namespace Dialog
		{
            /// <summary>
            /// Message handling from the native plugin.
            /// </summary>
			public class Messages
			{
				// Messages.
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogHasMessage();
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogGetFirstMessage(out PluginMessage msg);
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogRemoveFirstMessage();

                /// <summary>
                /// Message types.
                /// </summary>
				public enum MessageType
				{
                    /// <summary>No message type set.</summary>
					kDialog_NotSet,
                    /// <summary>Log message from the plugin.</summary>
					kDialog_Log,
                    /// <summary>Warning message from the plugin.</summary>
					kDialog_LogWarning,
                    /// <summary>Error message from the plugin.</summary>
					kDialog_LogError,

                    /// <summary>Dialog has closed and the result is ready.</summary>
					kDialog_GotDialogResult,		// Dialog has closed and the result is ready.
                    /// <summary>IME Dialog has closed and the result is ready.</summary>
					kDialog_GotIMEDialogResult,		// IME Dialog has closed and the result is ready.
                    /// <summary>Signin Dialog has closed and the result is ready.</summary>
					kDialog_GotSigninDialogResult,	// Signin Dialog has closed and the result is ready.
                    /// <summary>WebBrowser Dialog has closed and the result is ready.</summary>
					kDialog_GotWebBrowserDialogResult,
                    /// <summary>VrSetup Dialog has closed and the result is ready.</summary>
                    kDialog_GotVrSetupDialogResult //VrSetup Dialog has closed and the result is ready

                };

                /// <summary>
                /// Event handler for messages from the plugin.
                /// </summary>
                /// <param name="msg">Message</param>
                public delegate void EventHandler(PluginMessage msg);

                /// <summary>
                /// Message structure from the plugin.
                /// </summary>
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				public struct PluginMessage
				{
                    /// <summary>
                    /// Message type.
                    /// </summary>
					public MessageType type;

                    /// <summary>
                    /// Size of data.
                    /// </summary>
					public int dataSize;

                    /// <summary>
                    /// Pointer to data.
                    /// </summary>
					public IntPtr data;

                    /// <summary>
                    /// Text data from the message if applicable.
                    /// </summary>
					public string Text
					{
						get
						{
							switch (type)
							{
								case MessageType.kDialog_Log:
								case MessageType.kDialog_LogWarning:
								case MessageType.kDialog_LogError:
									return Marshal.PtrToStringAnsi(data);
							}
							return "no text";
						}
					}

                    /// <summary>
                    /// Integer data from the message if applicable.
                    /// </summary>
					public int Int
					{
						get
						{
							switch (type)
							{

								case MessageType.kDialog_GotDialogResult:
									return (int)data;
								case MessageType.kDialog_GotIMEDialogResult:
									return (int)data;
								case MessageType.kDialog_GotSigninDialogResult:
									return (int)data;
								case MessageType.kDialog_GotWebBrowserDialogResult:
									return (int)data;
                                case MessageType.kDialog_GotVrSetupDialogResult:
                                    return (int)data;

							}
							return 0;
						}
					}
				};

                /// <summary>
                /// Returns true if there is a message waiting to be processed.
                /// </summary>
                /// <returns>True is has a message</returns>
				public static bool HasMessage()
				{
					return PrxCommonDialogHasMessage();
				}

                /// <summary>
                /// Removes the first message from the queue.
                /// </summary>
				public static void RemoveFirstMessage()
				{
					PrxCommonDialogRemoveFirstMessage();
				}

                /// <summary>
                /// Gets the first message from the queue.
                /// </summary>
                /// <param name="msg">The message from the plugin</param>
				public static void GetFirstMessage(out PluginMessage msg)
				{
					PrxCommonDialogGetFirstMessage(out msg);
				}

			}
		} // Dialog
	} // PS5
} // Sony
