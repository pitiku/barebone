using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Sony
{
	namespace PS5
	{
		namespace Dialog
		{
            /// <summary>
            /// WebBrowser dialog handling class.
            /// </summary>
			public class WebBrowser
			{
                /// <summary>
                /// WebBrowser dialog result types.
                /// </summary>
				public enum EnumWebBrowserDialogResult
				{
                    /// <summary> The dialog was closed by the user operation or CloseDialog function </summary>
					RESULT_OK = 0,				// Closed by user operation or CloseDialog
                    /// <summary> The dialog was closed by a callback URL </summary>
                    RESULT_CALLBACK = 30,       //Closed by callback
                    /// <summary> The dialog was closed because it was prohibited by parental control </summary>
                    RESULT_BY_PARENTAL_CONTROL = 31, //	Closed because prohibited by parental control

                    /// <summary> Not used </summary>
					[Obsolete("The user cannot cancel the web browser dialog")] RESULT_USER_CANCELED,	// not used
				}

                /// <summary>
                /// WebBrowser dialog mode.
                /// </summary>
				public enum DialogMode
				{
                    /// <summary> Standard mode with default parts </summary>
					DEFAULT = 1,
                    /// <summary> Custom mode with user defined parts </summary>
					CUSTOM = 2
				}

                /// <summary>
                /// Custom parts that can be enabled/disabled in the dialog
                /// </summary>
				[Flags]
				public enum CustomParts : uint
				{
                    /// <summary> No custom parts </summary>
					NONE = 0,
                    /// <summary> Title bar </summary>
					TITLE = 1,
                    /// <summary> Address bar </summary>
					ADDRESS = 2,
                    /// <summary> Footer bar </summary>
					FOOTER = 4,
                    /// <summary> Background </summary>
					BACKGROUND = 8,
                    /// <summary> Wait dialog </summary>
					WAIT_DIALOG = 16
				}

                /// <summary>
                /// Custom controls that can be enabled/disabled in the dialog
                /// </summary>
				[Flags]
				public enum CustomControl : uint
				{
                    /// <summary> No custom controls </summary>
					NONE = 0,
                    /// <summary> Exit button </summary>
					EXIT = 1,
                    /// <summary> Reload button </summary>
					RELOAD = 2,
                    /// <summary> Back button </summary>
					BACK = 4,
                    /// <summary> Forward button </summary>
					FORWARD = 8,
                    /// <summary> Zoom button </summary>
					ZOOM = 16,
                    /// <summary> Exit button waits until page load is complete </summary>
					EXIT_UNTIL_COMPLETE = 32,
                    /// <summary> Option menu button </summary>
					OPTION_MENU = 64,
				}

                /// <summary>
                /// Animation types for showing/hiding the dialog
                /// </summary>
                public enum Animation : uint
				{
                    /// <summary> Default animation </summary>
					DEFAULT = 0,
                    /// <summary> Disable animation </summary>
					DISABLE = 1
				}

                /// <summary>
                /// IME options for the dialog
                /// </summary>
				[Flags]
				public enum ImeOption : uint
				{
                    /// <summary> Default IME options </summary>
					DEFAULT = 0,
                    /// <summary> Disable automatic capitalization </summary>
					NO_AUTO_CAPITALIZATION = 2,
                    /// <summary> Disable learning </summary>
					NO_LEARNING = 0x20,
                    /// <summary> Disable copy/paste </summary>
					DISABLE_COPY_PASTE = 0x80,
                    /// <summary> Disable automatic spacing </summary>
					DISABLE_AUTO_SPACE = 0x200
				}

                /// <summary>
                /// WebView options for the dialog
                /// </summary>
				[Flags]
				public enum WebViewOption : uint
				{
                    /// <summary> No special options </summary>
					NONE = 0,
                    /// <summary> Transparent background </summary>
					BACKGROUND_TRANSPARENCY = 1,
                    /// <summary> No cursor </summary>
					CURSOR_NONE = 2,
                    /// <summary> Disable submit button </summary>
					OSK_NO_SUBMIT = 4
				}

                /// <summary>
                /// Callback types for the dialog
                /// </summary>
                public enum CallbackType : uint
                {
                    /// <summary> No callback </summary>
                    PARAM_TYPE_NONE = 0,
                    /// <summary> Callback on specific URL </summary>
                    PARAM_TYPE_URL = 1,
                    /// <summary> Callback on specific regex </summary>
                    PARAM_TYPE_REGEX = 2
                }

                /// <summary>
                /// Parameters for the WebBrowser dialog
                /// </summary>
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
				public class WebBrowserParam
				{
                    /// <summary>
                    /// Dialog mode, either DEFAULT or CUSTOM
                    /// </summary>
					public DialogMode mode;

                    /// <summary>
                    /// User ID to open the dialog for
                    /// </summary>
					public int userId;

                    /// <summary>
                    /// The URL to open in the dialog
                    /// </summary>
					public string url;

                    /// <summary>
                    /// Width of the dialog
                    /// </summary>
					public ushort width;

                    /// <summary>
                    /// Height of the dialog
                    /// </summary>
                    public ushort height;

                    /// <summary>
                    /// X position of the dialog
                    /// </summary>
					public ushort positionX;

                    /// <summary>
                    /// Y position of the dialog
                    /// </summary>
                    public ushort positionY;

                    /// <summary>
                    /// Custom parts to enable/disable if mode is CUSTOM
                    /// </summary>
					public CustomParts parts;

                    /// <summary>
                    /// Width of the header
                    /// </summary>
					public ushort headerWidth;

                    /// <summary>
                    /// X position of the header
                    /// </summary>
                    public ushort headerPositionX;

                    /// <summary>
                    /// Y position of the header
                    /// </summary>
                    public ushort headerPositionY;

                    /// <summary>
                    /// Custom control of the browser
                    /// </summary>
					public CustomControl control;

                    /// <summary>
                    /// IME options for the dialog
                    /// </summary>
					public ImeOption imeOption;

                    /// <summary>
                    /// WebView options for the dialog
                    /// </summary>
					public WebViewOption webViewOption;

                    /// <summary>
                    /// Animation type
                    /// </summary>
					public Animation animation;

                    /// <summary>
                    /// The type of callback to use, if any
                    /// </summary>
                    public CallbackType callbackType;

                    /// <summary>
                    /// The callback URL or regex, depending on the callback type
                    /// </summary>
                    public string callbackURL;

                    /// <summary>
                    /// Constructor to set default values
                    /// </summary>
					public WebBrowserParam()
					{
						mode = DialogMode.DEFAULT;
                        callbackType = CallbackType.PARAM_TYPE_NONE;
                    }
				}

                /// <summary>
                /// Parameters for predetermined content domains
                /// </summary>
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
				public class WebBrowserPredeterminedContentParam
				{
                    /// <summary>
                    /// Array of domains for predetermined content
                    /// </summary>
					public string [] domain;

                    /// <summary>
                    /// Constructor to initialize the domain array
                    /// </summary>
					public WebBrowserPredeterminedContentParam()
					{
						domain = new string[5];    //only supporting 5 ... not all SCE_WEB_BROWSER_DIALOG_DOMAIN_COUNT
					}
				}

                /// <summary>
                /// Maximum size of the callback URL string
                /// </summary>
                const int SCE_WEB_BROWSER_DIALOG_URL_SIZE_EXTENDED = 8192;

                /// <summary>
                /// WebBrowser dialog result structure
                /// </summary>
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				public struct WebBrowserDialogResult
				{

                    /// <summary>
                    /// The result of closing the dialog, either prevented from Parental Controls, from a Callback
                    /// or from the User closing it/using the DialogClose function
                    /// </summary>
					public EnumWebBrowserDialogResult result;

                    /// <summary>
                    /// The type of callback, if the browser was closed from a callback
                    /// </summary>
                    public CallbackType callbackType;

                    /// <summary>
                    /// The URL obtained from a callback, if the browser was closed by a callback
                    /// </summary>
                    /// <remarks>This encapsulates the data and buffer URLs that are obtained from the SDK
                    /// function. It will always hold the URL, without additional calls as long as it is less than
                    /// SCE_WEB_BROWSER_DIALOG_URL_SIZE_EXTENDED</remarks>
                    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = SCE_WEB_BROWSER_DIALOG_URL_SIZE_EXTENDED)]
                    public string callbackURL;
                };

				[DllImport(LibraryInfo.LibraryName)]
				private static extern int PrxWebBrowserDialogTerminate();

                [DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
                private static extern bool PrxWebBrowserDialogClose();


				// Signin Dialog.
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxWebBrowserDialogIsDialogOpen();
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxWebBrowserDialogOpen(WebBrowserParam webBrowserParam);
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]

				private static extern bool PrxWebBrowserDialogOpenForPredeterminedContent(WebBrowserParam webBrowserParam, string domain0, string domain1, string domain2, string domain3, string domain4 );
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]



				private static extern int PrxWebBrowserDialogResetCookie();
				[DllImport(LibraryInfo.LibraryName)]

				private static extern int PrxWebBrowserDialogSetCookie(string url, string cookie);
				[DllImport(LibraryInfo.LibraryName)]

				private static extern bool PrxWebBrowserDialogGetResult(out WebBrowserDialogResult result);

				// Messages.
				[DllImport(LibraryInfo.LibraryName)] [return: MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogHasMessage();
				[DllImport(LibraryInfo.LibraryName)] [return: MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogGetFirstMessage(out Dialog.Messages.PluginMessage msg);
				[DllImport(LibraryInfo.LibraryName)] [return: MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogRemoveFirstMessage();

				/// <summary>
                /// Event handlers.
                /// </summary>
				public static event Dialog.Messages.EventHandler OnGotWebBrowserDialogResult;

				/// <summary>
                /// Is the Signin dialog open?
                /// </summary>
				public static bool IsDialogOpen
				{
					get { return PrxWebBrowserDialogIsDialogOpen(); }
				}

                /// <summary>
                /// Open the WebBrowser dialog with the specified parameters.
                /// </summary>
                /// <param name="webBrowserParam">The web browser params</param>
                /// <returns>True is brower opened</returns>
				public static bool Open(WebBrowserParam webBrowserParam)
				{
					bool ret = PrxWebBrowserDialogOpen(webBrowserParam);
					return ret;
				}

                /// <summary>
                /// Open the WebBrowser dialog with predetermined content domains.
                /// </summary>
                /// <param name="webBrowserParam">The web browser params</param>
                /// <param name="param2">Content params</param>
                /// <returns>True is brower opened</returns>
				public static bool OpenForPredeterminedContent(WebBrowserParam webBrowserParam, WebBrowserPredeterminedContentParam param2)
				{
					bool ret = PrxWebBrowserDialogOpenForPredeterminedContent(webBrowserParam, param2.domain[0], param2.domain[1], param2.domain[2], param2.domain[3], param2.domain[4] );
					return ret;
				}

                /// <summary>
                /// Reset all cookies used by the web browser dialog.
                /// </summary>
                /// <returns>Result of cookie reset</returns>
				public static int ResetCookie()
				{
					return PrxWebBrowserDialogResetCookie();
				}

                /// <summary>
                /// Set a cookie for a specific URL used by the web browser dialog.
                /// </summary>
                /// <param name="url">The URL</param>
                /// <param name="cookie">The cookie string</param>
                /// <returns>Result of setting the cookie</returns>
				public static int SetCookie(string url, string cookie)
				{
					return PrxWebBrowserDialogSetCookie(url, cookie);
				}

                /// <summary>
                /// Get the result of the web browser dialog after it has been closed.
                /// </summary>
                /// <returns>The brower dialog result</returns>
				public static WebBrowserDialogResult GetResult()
				{
					WebBrowserDialogResult result = new WebBrowserDialogResult();
					PrxWebBrowserDialogGetResult(out result);
					return result;
				}

                /// <summary>
                /// Process a message from the plugin and trigger corresponding events.
                /// </summary>
                /// <param name="msg">The plugin message</param>
				public static void ProcessMessage(Dialog.Messages.PluginMessage msg)
				{
					// Interpret the message and trigger corresponding events.
					switch (msg.type)
					{
						 case Dialog.Messages.MessageType.kDialog_GotWebBrowserDialogResult:
						 	if (OnGotWebBrowserDialogResult != null) OnGotWebBrowserDialogResult(msg);
						break;
					}
				}

                /// <summary>
                /// Close the web browser dialog if it is open.
                /// </summary>
                /// <returns>True if dialog closed</returns>
                public static bool Close()
                {
                    return PrxWebBrowserDialogClose();
                }

                /// <summary>
                /// Terminate the web browser dialog system
                /// </summary>
				public static void Terminate()
				{
					PrxWebBrowserDialogTerminate();
				}
			}
		} // Dialog
	} // PS5
} // Sony
