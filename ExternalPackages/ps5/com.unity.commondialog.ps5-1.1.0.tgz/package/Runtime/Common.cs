using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Sony
{
	namespace PS5
	{
		namespace Dialog
		{
            /// <summary>
            /// Common Dialog functions.
            /// </summary>
			public class Common
			{
				/// <summary>
                /// System message dialog types, these must exactly match the values defined by SceMsgDialogSystemMessageType.
                /// </summary>
				public enum SystemMessageType
				{
                    /// <summary> Empty Store. </summary>
					TRC_EMPTY_STORE = 0,
                    /// <summary> Camera not connected </summary>
					CAMERA_NOT_CONNECTED = 4,
                    /// <summary> Communication is restricted.  </summary>
					PSN_COMMUNICATION_RESTRICTION = 6,
				}

				/// <summary>
                /// User message dialog types, these must exactly match the values defined by SceMsgDialogButtonType.
                /// </summary>
				public enum UserMessageType
				{
                    /// <summary> OK button only. </summary>
					OK = 0,
                    /// <summary> OK button only. </summary>
					Ok = 0,
                    /// <summary> Yes and No buttons. </summary>
					YESNO = 1,
                    /// <summary> Yes and No buttons. </summary>
					YesNo = 1,
                    /// <summary> No buttons. </summary>
					NONE = 2,
                    /// <summary> No buttons. </summary>
					None = 2,
                    /// <summary> OK and Cancel buttons. </summary>
					OK_CANCEL = 3,
                    /// <summary> OK and Cancel buttons. </summary>
					OkCancel = 3,
                    /// <summary> Wait </summary>
					WAIT = 5,
                    /// <summary> Wait </summary>
					Wait = 5,
                    /// <summary> Wait and Cancel buttons. </summary>
					WAIT_CANCEL = 6,
                    /// <summary> Wait and Cancel buttons. </summary>
					WaitCancel = 6,
                    /// <summary> Yes and No buttons, with No as the focused button. </summary>
					YESNO_FOCUS_NO = 7,
                    /// <summary> Yes and No buttons, with No as the focused button. </summary>
					YesNo_FocusNo = 7,
                    /// <summary> OK and Cancel buttons, with Cancel as the focused button. </summary>
					OK_CANCEL_FOCUS_CANCEL = 8,
                    /// <summary> OK and Cancel buttons, with Cancel as the focused button. </summary>
					OkCancel_FocusCancel = 8,
                    /// <summary> Two custom buttons. </summary>
					TWO_BUTTONS = 9,
                    /// <summary> Two custom buttons. </summary>
					TwoButtons = 9
				}

                /// <summary>
                /// Common dialog result codes, these must exactly match the values defined by SceMsgDialogResult.
                /// </summary>
				public enum CommonDialogResult
				{
                    /// <summary> No result button set. </summary>
					RESULT_BUTTON_NOT_SET,
                    /// <summary> OK button pressed. </summary>
					RESULT_BUTTON_OK,
                    /// <summary> Cancel button pressed. </summary>
					RESULT_BUTTON_CANCEL,
                    /// <summary> Yes button pressed. </summary>
					RESULT_BUTTON_YES,
                    /// <summary> No button pressed. </summary>
					RESULT_BUTTON_NO,
                    /// <summary> First custom button pressed. </summary>
					RESULT_BUTTON_1,
                    /// <summary> Second custom button pressed. </summary>
					RESULT_BUTTON_2,
                    /// <summary> Third custom button pressed. </summary>
					RESULT_BUTTON_3,
                    /// <summary> Dialog canceled </summary>
					RESULT_CANCELED,
                    /// <summary> Dialog aborted </summary>
					RESULT_ABORTED,
                    /// <summary> Dialog closed </summary>
					RESULT_CLOSED,
				}

				[DllImport(LibraryInfo.LibraryName)]
				private static extern int PrxCommonDialogInitialise();
				[DllImport(LibraryInfo.LibraryName)]
				private static extern void PrxCommonDialogUpdate();

				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogIsDialogOpen();

				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
                private static extern bool PrxCommonDialogErrorMessage(UInt32 errorCode, int userId = 0) ;

				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogSystemMessage(SystemMessageType type,  int userId);
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogClose();

                [DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
                private static extern bool PrxErrorDialogIsDialogOpen();

				[DllImport(LibraryInfo.LibraryName, CharSet = CharSet.Ansi)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogProgressBar(string str);
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogProgressBarSetPercent(int percent);
				[DllImport(LibraryInfo.LibraryName, CharSet = CharSet.Ansi)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogProgressBarSetMessage(string str);

				[DllImport(LibraryInfo.LibraryName, CharSet = CharSet.Ansi)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogUserMessage(UserMessageType type, string str, string button1, string button2);

				[DllImport(LibraryInfo.LibraryName)]
				private static extern CommonDialogResult PrxCommonDialogGetResult();

				/// <summary>
                /// Event handlers.
                /// </summary>
				public static event Dialog.Messages.EventHandler OnGotDialogResult;

				/// <summary>
                /// Is a common dialog open?
                /// </summary>
				public static bool IsDialogOpen
				{
					get { return PrxCommonDialogIsDialogOpen(); }
				}

                /// <summary>
                /// Is the error dialog open?
                /// </summary>
                public static bool IsErrorDialogOpen
                {
                    get { return PrxErrorDialogIsDialogOpen(); }
                }

				/// <summary>
                /// Display an error message.
                /// </summary>
                /// <param name="errorCode"> The error code to display </param>
                /// <param name="userId">The user id for the dialog</param>
                /// <returns>True if dialog shown</returns>
				public static bool ShowErrorMessage(UInt32 errorCode, int userId = 0)
				{
					return PrxCommonDialogErrorMessage(errorCode, userId);
				}

                /// <summary>
                /// Display a system message.
                /// </summary>
                /// <param name="type">The system message type</param>
                /// <param name="userId">The user id for the dialog</param>
                /// <returns>True if dialog shown</returns>
                public static bool ShowSystemMessage(SystemMessageType type,  int userId)
				{
					return PrxCommonDialogSystemMessage(type, userId);
				}

                /// <summary>
                /// Display a progress bar.
                /// </summary>
                /// <param name="message">The message to display</param>
                /// <returns>True if dialog shown</returns>
                public static bool ShowProgressBar(string message)
				{
					return PrxCommonDialogProgressBar(message);
				}

                /// <summary>
                /// Set progress bar percentage (0-100).
                /// </summary>
                /// <param name="percent">The percentage for the progress bare</param>
                /// <returns>True if dialog shown</returns>
                public static bool SetProgressBarPercent(int percent)
				{
					return PrxCommonDialogProgressBarSetPercent(percent);
				}

                /// <summary>
                /// Set progress bar message string.
                /// </summary>
                /// <param name="message">The message to display</param>
                /// <returns>True if progress bar message shown</returns>
                public static bool SetProgressBarMessage(string message)
				{
					return PrxCommonDialogProgressBarSetMessage(message);
				}

                /// <summary>
                /// Show a user message.
                /// </summary>
                /// <param name="type">The user message type</param>
                /// <param name="str">The text is display</param>
                /// <param name="button1">The text for button 1</param>
                /// <param name="button2">The text for button 2</param>
                /// <returns>True if dialog shown</returns>
                public static bool ShowUserMessage(UserMessageType type, string str, string button1="", string button2="")
				{
					return PrxCommonDialogUserMessage(type, str, button1, button2);
				}

                /// <summary>
                /// Show a user message.
                /// </summary>
                /// <param name="type">The user message type</param>
                /// <param name="infoBar">If true show as an info bar</param>
                /// <param name="str">The text is display</param>
                /// <param name="button1">The text for button 1</param>
                /// <param name="button2">The text for button 2</param>
                /// <returns>True if dialog shown</returns>
                [Obsolete("Please use the alternative ShowUserMessage method as the infoBar parameter is not supported.")]
                public static bool ShowUserMessage(UserMessageType type, bool infoBar, string str, string button1 = "", string button2 = "")
                {
                    return PrxCommonDialogUserMessage(type, str, button1, button2);
                }

                /// <summary>
                /// Close the dialog.
                /// </summary>
                /// <returns>True if dialog closed</returns>
                public static bool Close()
				{
					return PrxCommonDialogClose();
				}

                /// <summary>
                /// Get the result from the dialog that's just closed.
                /// </summary>
                /// <returns>Dialog result</returns>
                public static CommonDialogResult GetResult()
				{
					CommonDialogResult result = PrxCommonDialogGetResult();
					return result;
				}

				/// <summary>
                /// Process messages.
                /// </summary>
                /// <param name="msg">The message to display</param>
				public static void ProcessMessage(Dialog.Messages.PluginMessage msg)
				{
					// Interpret the message and trigger corresponding events.
					switch (msg.type)
					{
						case Dialog.Messages.MessageType.kDialog_GotDialogResult:
							if (OnGotDialogResult != null) OnGotDialogResult(msg);
							break;
					}
				}

                /// <summary>
                /// Initialise the common dialog system.
                /// </summary>
				public static void Initialise()
				{
					PrxCommonDialogInitialise();
				}

                /// <summary>
                /// Update the common dialog system.
                /// </summary>
				public static void Update()
				{
					PrxCommonDialogUpdate();
				}
			}
		} // Dialog
	} // PS4
} // Sony
