using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.CommonDialog.PS5.Editor")]
[assembly: InternalsVisibleTo("Unity.CommonDialog.PS5.Tests.Editor")]
