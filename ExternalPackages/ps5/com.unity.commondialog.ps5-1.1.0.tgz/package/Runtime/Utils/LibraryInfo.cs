
namespace Sony.PS5.Dialog
{
    internal static class LibraryInfo
    {
        internal const string LibraryName = "CommonDialog";
        internal static string LibraryNameWithExtension => $"{LibraryName}.prx";
    }
}
