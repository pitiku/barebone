using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Sony
{
    namespace PS5
    {
        namespace Dialog
        {
            /// <summary>
            /// VrSetup dialog handling class.
            /// </summary>
            public class VrSetup
            {
                /// <summary>
                /// VrSetup dialog result types.
                /// </summary>
                public enum VrSetupDialogResult
                {
                    /// <summary>User selected either close button or Enter button</summary>
                    RESULT_OK = 0,
                    /// <summary>User performed cancel operation.</summary>
                    RESULT_USER_CANCELED = 1,
                    /// <summary>Result not set yet.</summary>
                    RESULT_NOT_SET = 2,
                    /// <summary>Process not finished yet.</summary>
                    RESULT_PROCESS_NOT_FINISHED = 3
                }

                [DllImport(LibraryInfo.LibraryName)] [return: MarshalAs(UnmanagedType.I1)]
                private static extern bool PrxVrSetupDialogClose();
                [DllImport(LibraryInfo.LibraryName)] [return: MarshalAs(UnmanagedType.I1)]
                private static extern bool PrxVrSetupDialogOpen();

                [DllImport(LibraryInfo.LibraryName)] [return: MarshalAs(UnmanagedType.I1)]
                private static extern bool PrxVrSetupDialogIsDialogOpen();

                [DllImport(LibraryInfo.LibraryName)]
                private static extern VrSetupDialogResult PrxVrSetupDialogGetResult();

                /// <summary>
                /// Event handlers.
                /// </summary>

                public static event Dialog.Messages.EventHandler OnGotVrSetupDialogResult;

                /// <summary>
                /// Close the VrSetup dialog.
                /// </summary>
                /// <returns>True is closed</returns>
                public static bool Close()
                {

                    return PrxVrSetupDialogClose();
                }

                /// <summary>
                /// Open the VrSetup dialog.
                /// </summary>
                /// <returns>True is dialog open</returns>
                public static bool Open()
                {

                    return PrxVrSetupDialogOpen();
                }

                /// <summary>
                /// Is the VrSetup dialog open?
                /// </summary>
                public static bool IsDialogOpen
                {
                    get { return PrxVrSetupDialogIsDialogOpen(); }
                }

                /// <summary>
                /// Get the result of the VrSetup dialog.
                /// </summary>
                /// <returns>The dialog result</returns>
                public static VrSetupDialogResult GetResult()
                {
                    VrSetupDialogResult result = PrxVrSetupDialogGetResult();
                    return result;
                }

                /// <summary>
                /// Process a message from the plugin.
                /// </summary>
                /// <param name="msg">The plugin message</param>
                public static void ProcessMessage(Dialog.Messages.PluginMessage msg)
                {
                    // Interpret the message and trigger corresponding events.
                    switch (msg.type)
                    {
                        case Dialog.Messages.MessageType.kDialog_GotVrSetupDialogResult:
                            if (OnGotVrSetupDialogResult != null) OnGotVrSetupDialogResult(msg);
                            break;
                    }
                }
            }
        }
    }
}
