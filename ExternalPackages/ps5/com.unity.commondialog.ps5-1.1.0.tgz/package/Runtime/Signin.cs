using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Sony
{
	namespace PS5
	{
		namespace Dialog
		{
            /// <summary>
            /// Signin dialog handling class.
            /// </summary>
			public class Signin
			{
                /// <summary>
                /// Signin dialog result types.
                /// </summary>
				public enum EnumSigninDialogResult
				{
                    /// <summary>User selected either close button or Enter button</summary>
					RESULT_OK,				// User selected either close button or Enter button
                    /// <summary>User performed cancel operation.</summary>
					RESULT_USER_CANCELED,	// User performed cancel operation.
				}

                /// <summary>
                /// Signin dialog result structure.
                /// </summary>
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				public struct SigninDialogResult
				{
                    /// <summary>Result of the dialog.</summary>
					public EnumSigninDialogResult result;
				};

				// Signin Dialog.
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxSigninDialogIsDialogOpen();
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxSigninDialogOpen(int userId);
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxSigninDialogGetResult(out SigninDialogResult result);

				// Messages.
				[DllImport(LibraryInfo.LibraryName)] [return: MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogHasMessage();
				[DllImport(LibraryInfo.LibraryName)] [return: MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogGetFirstMessage(out Dialog.Messages.PluginMessage msg);
				[DllImport(LibraryInfo.LibraryName)] [return: MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogRemoveFirstMessage();

				/// <summary>
                /// Event handlers.
                /// </summary>
				public static event Dialog.Messages.EventHandler OnGotSigninDialogResult;

				/// <summary>
                /// Is the Signin dialog open?
                /// </summary>
				public static bool IsDialogOpen
				{
					get { return PrxSigninDialogIsDialogOpen(); }
				}

                /// <summary>
                /// Open the Signin dialog for the specified user.
                /// </summary>
                /// <param name="userId">The user id</param>
                /// <returns>True is dialog open</returns>
				public static bool Open(int userId)
				{
					bool ret = PrxSigninDialogOpen(userId);
					return ret;
				}

                /// <summary>
                /// Get the result of the Signin dialog.
                /// </summary>
                /// <returns>The result structure</returns>
				public static SigninDialogResult GetResult()
				{
					SigninDialogResult result = new SigninDialogResult();
					PrxSigninDialogGetResult(out result);
					return result;
				}

                /// <summary>
                /// Process a message from the native plugin.
                /// </summary>
                /// <param name="msg">The message</param>
				public static void ProcessMessage(Dialog.Messages.PluginMessage msg)
				{
					// Interpret the message and trigger corresponding events.
					switch (msg.type)
					{
						case Dialog.Messages.MessageType.kDialog_GotSigninDialogResult:
							if (OnGotSigninDialogResult != null) OnGotSigninDialogResult(msg);
						break;
					}
				}

                /// <summary>
                /// Initialise the Signin dialog system.
                /// </summary>
				public static void Initialise()
				{
				}

                /// <summary>
                /// Update the Signin dialog system.
                /// </summary>
				public static void Update()
				{
				}
			}
		} // Dialog
	} // PS5
} // Sony
