using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Sony
{
	namespace PS5
	{
		namespace Dialog
		{
            /// <summary>
            /// Input Method Editor (IME) Dialog
            /// </summary>
			public class Ime
			{
				/// <summary>
                /// ImeParam enterLabel
                /// </summary>
				public enum EnterLabel
				{
                    /// <summary> Default label </summary>
					DEFAULT,
                    /// <summary> Send label </summary>
					SEND,
                    /// <summary> Search label </summary>
					LABEL_SEARCH,
                    /// <summary> Go label </summary>
					LABEL_GO,
				}

                /// <summary>
                /// ImeParam inputMethod
                /// </summary>
				public enum InputMethod
				{
                    /// <summary> Default input method </summary>
					DEFAULT,
				}

				/// <summary>
                /// ImeParam type
                /// </summary>
				public enum Type
				{
                    /// <summary> UI for regular text input </summary>
					DEFAULT,		    // UI for regular text input
                    /// <summary> UI for alphanumeric character input </summary>
					BASIC_LATIN,	    // UI for alphanumeric character input
                    /// <summary> UI for entering an email address </summary>
					URL,	        	// UI for entering URL
                    /// <summary> UI for entering an email address </summary>
					MAIL,		        // UI for entering an email address
                    /// <summary> UI for entering a password </summary>
					NUMBER,		    // UI for number input
				}

                /// <summary>
                /// IME horizontal display origins
                /// </summary>
                public enum HorizontalAlignment
				{
                    /// <summary> Left edge of OSK </summary>
					LEFT,				//<E Left edge of OSK
                    /// <summary> Horizontal center of OSK </summary>
					CENTER,				//<E Horizontal center of OSK
                    /// <summary> Right edge of OSK </summary>
					RIGHT               //<E Right edge of OSK
                }

                /// <summary>
                /// IME vertical display origins
                /// </summary>
                public enum VerticalAlignment
				{
                    /// <summary> Top edge of OSK </summary>
					TOP,					//<E Top edge of OSK
                    /// <summary> Vertical center of OSK </summary>
					ENTER,				//<E Vertical center of OSK
                    /// <summary> Bottom edge of OSK </summary>
					BOTTOM,				//<E Bottom edge of OSK
				}

                /// <summary>
                /// IME prioritized input panel
                /// </summary>
                public enum PanelPriority
				{
                    /// <summary> Display the standard panel </summary>
					DEFAULT = 0,	//<E Display the standard panel
                    /// <summary> Display the hiragana panel </summary>
					ALPHABET = 1,	//<E Display the English alphabet panel
                    /// <summary> Display the symbol panel </summary>
					SYMBOL = 2,	//<E Display the symbol panel
                    /// <summary> Display the accent panel </summary>
					ACCENT = 3,	//<E Display the accent panel
				};

				/// <summary>
                /// ImeParam supported languages, can be OR'd together.
                /// </summary>
				[Flags]
				public enum FlagsSupportedLanguages : long
				{
                    /// <summary> Danish </summary>
					LANGUAGE_DANISH = 0x00000001,
                    /// <summary> German </summary>
					LANGUAGE_GERMAN = 0x00000002,
                    /// <summary> English (US) </summary>
					LANGUAGE_ENGLISH_US = 0x00000004,
                    /// <summary> Spanish </summary>
					LANGUAGE_SPANISH = 0x00000008,
                    /// <summary> French </summary>
					LANGUAGE_FRENCH = 0x00000010,
                    /// <summary> Italian </summary>
					LANGUAGE_ITALIAN = 0x00000020,
                    /// <summary> Dutch </summary>
					LANGUAGE_DUTCH = 0x00000040,
                    /// <summary> Norwegian </summary>
					LANGUAGE_NORWEGIAN = 0x00000080,
                    /// <summary> Polish </summary>
					LANGUAGE_POLISH = 0x00000100,
                    /// <summary> Portuguese (Portugal) </summary>
					LANGUAGE_PORTUGUESE_PT = 0x00000200,
                    /// <summary> Russian </summary>
					LANGUAGE_RUSSIAN = 0x00000400,
                    /// <summary> Finnish </summary>
					LANGUAGE_FINNISH = 0x00000800,
                    /// <summary> Swedish </summary>
					LANGUAGE_SWEDISH = 0x00001000,
                    /// <summary> Japanese </summary>
					LANGUAGE_JAPANESE = 0x00002000,
                    /// <summary> Korean </summary>
					LANGUAGE_KOREAN = 0x00004000,
                    /// <summary> Simplified Chinese </summary>
					LANGUAGE_SIMPLIFIED_CHINESE = 0x00008000,
                    /// <summary> Traditional Chinese </summary>
					LANGUAGE_TRADITIONAL_CHINESE = 0x00010000,
                    /// <summary> Portuguese (Brazil) </summary>
					LANGUAGE_PORTUGUESE_BR = 0x00020000,
                    /// <summary> English (UK) </summary>
					LANGUAGE_ENGLISH_GB = 0x00040000,
                    /// <summary> Turkish </summary>
					LANGUAGE_TURKISH = 0x00080000,
                    /// <summary> Spanish (Latin America) </summary>
					LANGUAGE_SPANISH_LA = 0x00100000,
				}


                /// <summary>
                /// ImeParam option, can be OR'd together.
                /// </summary>
				[Flags]
				public enum Option
				{
                    /// <summary> No specification (default) </summary>
					DEFAULT = 0x00000000,		//<E No specification (default)
                    /// <summary> Multiline input mode </summary>
					MULTILINE = 0x00000001,		//<E Multiline input mode
                    /// <summary> Prohibit auto capitalization </summary>
					NO_AUTO_CAPITALIZATION = 0x00000002,		//<E Prohibit auto capitalization
                    /// <summary> Password mode </summary>
					PASSWORD = 0x00000004,		//<E Password mode
                    /// <summary> Force the specified languages to be available </summary>
					LANGUAGES_FORCED = 0x00000008,		//<E Force the specified languages to be available
                    /// <summary> When external keyboard is connected, give precedence to it </summary>
					EXT_KEYBOARD = 0x00000010,		//<E When external keyboard is connected, give precedence to it
                    /// <summary> Do not add strings to the input support dictionary </summary>
					NO_LEARNING = 0x00000020,		//<E Do not add strings to the input support dictionary
                    /// <summary> Prohibit movement of IME panel by analog stick and fix the display position </summary>
					FIXED_POSITION = 0x00000040,		//<E Prohibit movement of IME panel by analog stick and fix the display position
                    /// <summary> Prohibit copy/paste </summary>
					DISABLE_COPY_PASTE = 0x00000080,		//<E Prohibit copy/paste
                    /// <summary> Disable automatic resume </summary>
					DISABLE_RESUME = 0x00000100,		//<E Disable automatic resume
                    /// <summary> Disable input automatic space after word </summary>
					DISABLE_AUTO_SPACE = 0x00000200,		//<E Disable input automatic space after word.
				}

                /// <summary>
                /// ImeParamExtended option, can be OR'd together.
                /// </summary>
				[Flags]
				public enum ExtOption
				{
                    /// <summary> Default </summary>
					DEFAULT = 0x00000000,		//<E No specification (default)
                    /// <summary> Enable color settings </summary>
					SET_COLOR = 0x00000001,		//<E Enable color settings
                    /// <summary> Enable the display panel priority setting </summary>
					SET_PRIORITY = 0x00000002,		//<E Enable the display panel priority setting
                    /// <summary> Enable extended keyboard settings </summary>
					PRIORITY_SHIFT = 0x00000004,		//<E Shift option
                    /// <summary> Enable full-width character input </summary>
					PRIORITY_FULL_WIDTH = 0x00000008,		//<E Full-width option
                    /// <summary> Enable fixed panel option </summary>
					PRIORITY_FIXED_PANEL = 0x00000010,		//<E Fixed panel option
                    /// <summary> Disable touch input </summary>
					DISABLE_POINTER = 0x00000040,      //<E Disable gyro pointer mode
                    /// <summary> Enable dictionary file provided by the application </summary>
					ENABLE_ADDITIONAL_DICTIONARY = 0x00000080,	//<E Enable dictionary file provided by the application
                    /// <summary> Disable startup sound effect </summary>
					DISABLE_STARTUP_SE = 0x00000100,		//<E Disable startup SE
                    /// <summary> Disable IME when external keyboard is connected </summary>
					DISABLE_LIST_FOR_EXT_KEYBOARD = 0x00000200,		//<E
                    /// <summary> Hide IME when external keyboard is connected </summary>
					HIDE_KEYPANEL_IF_EXT_KEYBOARD = 0x00000400,	//<E
                    /// <summary> Initialize the external keyboard mode each time the IME is started </summary>
					INIT_EXT_KEYBOARD_MODE = 0x00000800	//<E
				}

                /// <summary>
                /// Parameters for the IME Dialog
                /// </summary>
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				public class SceImeDialogParam
				{
                    /// <summary>
                    /// User ID that is using the IME dialog. This is used to select the appropriate user dictionary.
                    /// </summary>
					public uint userId;

                    /// <summary>
                    /// Type of IME dialog to display.
                    /// </summary>
					public Type type;

                    /// <summary>
                    /// Supported languages
                    /// </summary>
					public FlagsSupportedLanguages supportedLanguages;

                    /// <summary>
                    /// Label for the Enter key.
                    /// </summary>
					public EnterLabel enterLabel;

                    /// <summary>
                    /// Input method for the IME dialog.
                    /// </summary>
					public InputMethod inputMethod;

                    /// <summary>
                    /// Pointer to a filter callback function.
                    /// </summary>
					public IntPtr _filter;		// TODO: callback for filtering text

                    /// <summary>
                    /// Options for the IME dialog
                    /// </summary>
					public Option option;

                    /// <summary>
                    /// Maximum text length, in characters, that can be entered. If 0, the default maximum length is used.
                    /// </summary>
					public uint maxTextLength;


					IntPtr _inputTextBuffer;

                    /// <summary>
                    /// X position of the IME dialog on the screen, in pixels. The default value is 0.0f.
                    /// </summary>
					public float posx;

                    /// <summary>
                    /// Y position of the IME dialog on the screen, in pixels. The default value is 0.0f.
                    /// </summary>
					public float posy;

                    /// <summary>
                    /// Horizontal alignment of the IME dialog on the screen. The default value is LEFT.
                    /// </summary>
					public HorizontalAlignment horizontalAlignment;

                    /// <summary>
                    /// Vertical alignment of the IME dialog on the screen. The default value is TOP.
                    /// </summary>
					public VerticalAlignment verticalAlignment;


					IntPtr _placeholder;
					IntPtr _title;
					Byte r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15;  //int8_t reserved[16];

                    /// <summary>
                    /// Title of the IME dialog.
                    /// </summary>
					public string title
					{
						get { return Marshal.PtrToStringUni(_title); }
						set { _title = Marshal.StringToCoTaskMemUni(value); }
					}

                    /// <summary>
                    /// Initial text in the input text buffer.
                    /// </summary>
					public string inputTextBuffer
					{
						get { return Marshal.PtrToStringUni(_inputTextBuffer); }
						set { _inputTextBuffer = Marshal.StringToCoTaskMemUni(value); }
					}

                    /// <summary>
                    /// Placeholder text to display when the input text buffer is empty.
                    /// </summary>
					public string placeholder
					{
						get { return Marshal.PtrToStringUni(_placeholder); }
						set { _placeholder = Marshal.StringToCoTaskMemUni(value); }
					}

                    /// <summary>
                    /// Constructor, sets defaults
                    /// </summary>
					public SceImeDialogParam()
					{
						userId = 0;
						type = Type.DEFAULT;
						supportedLanguages = 0;
						enterLabel = EnterLabel.DEFAULT;
						inputMethod = InputMethod.DEFAULT;
						_filter = IntPtr.Zero;
						option = 0;
						maxTextLength = 0;
						_inputTextBuffer = IntPtr.Zero;
						posx = 0.0f;
						posy = 0.0f;
						horizontalAlignment = HorizontalAlignment.LEFT;
						verticalAlignment = VerticalAlignment.TOP;
						_placeholder = IntPtr.Zero;
						_title = IntPtr.Zero;
						r0 = r1 = r2 = r3 = r4 = r5 = r6 = r7 = r8 = r9 = r10 = r11 = r12 = r13 = r14 = r15 = 0;
					}

                    /// <summary>
                    /// Destructor, free allocated memory
                    /// </summary>
					~SceImeDialogParam()
					{
						Marshal.FreeCoTaskMem(_title);
						Marshal.FreeCoTaskMem(_inputTextBuffer);
						Marshal.FreeCoTaskMem(_placeholder);
					}
				};

                /// <summary>
                /// Color structure for IME dialog
                /// </summary>
				public struct SceImeColor
				{
                    /// <summary> Red component </summary>
					public byte r;
                    /// <summary> Green component </summary>
                    public byte g;
                    /// <summary> Blue component </summary>
                    public byte b;
                    /// <summary> Alpha component </summary>
                    public byte a;
				};

                /// <summary>
                /// Extended parameters for the IME dialog
                /// </summary>
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				public class SceImeParamExtended
				{
                    /// <summary>
                    /// Options for the extended parameters
                    /// </summary>
					public ExtOption option;

                    /// <summary>
                    /// Color settings for the IME dialog
                    /// </summary>
					public SceImeColor colorBase;

                    /// <summary>
                    /// Color settings for the IME dialog
                    /// </summary>
					public SceImeColor colorLine;

                    /// <summary>
                    /// Color settings for the IME dialog
                    /// </summary>
					public SceImeColor colorTextField;

                    /// <summary>
                    /// Color settings for the IME dialog
                    /// </summary>
					public SceImeColor colorPreedit;

                    /// <summary>
                    /// Color settings for the IME dialog
                    /// </summary>
					public SceImeColor colorButtonDefault;

                    /// <summary>
                    /// Color settings for the IME dialog
                    /// </summary>
					public SceImeColor colorButtonFunction;

                    /// <summary>
                    /// Color settings for the IME dialog
                    /// </summary>
					public SceImeColor colorButtonSymbol;

                    /// <summary>
                    /// Color settings for the IME dialog
                    /// </summary>
					public SceImeColor colorText;

                    /// <summary>
                    /// Color settings for the IME dialog
                    /// </summary>
					public SceImeColor colorSpecial;

                    /// <summary>
                    /// Color settings for the IME dialog
                    /// </summary>
					public PanelPriority priority;
					uint padding;	// padding to get 64bit pointer aligned correctly
					IntPtr _additionalDictionaryPath;

                    /// <summary>
                    /// Pointer to a keyboard filter callback function.
                    /// </summary>
					public IntPtr _extKeyboardFilter;	// todo keyboard filter callback

                    /// <summary>
                    /// Disable IME when external keyboard is connected
                    /// </summary>
					public uint disableDevice;

                    /// <summary>
                    /// External keyboard mode
                    /// </summary>
					public uint extKeyboardMode;

                    /// <summary>
                    /// Path to an additional dictionary file provided by the application.
                    /// </summary>
					public string additionalDictionaryPath
					{
						get { return Marshal.PtrToStringUni(_additionalDictionaryPath); }
						set { _additionalDictionaryPath = Marshal.StringToCoTaskMemUni(value); }
					}

                    /// <summary>
                    /// Constructor, sets defaults
                    /// </summary>
					public SceImeParamExtended()
					{
						option = 0;
					}

                    /// <summary>
                    /// Destructor, free allocated memory
                    /// </summary>
					~SceImeParamExtended()
					{
						Marshal.FreeCoTaskMem(_additionalDictionaryPath);
					}
				};

                /// <summary>
                /// Result of the IME dialog
                /// </summary>
				public enum EnumImeDialogResult
				{
                    /// <summary> User selected either close button or Enter button </summary>
					RESULT_OK,				// User selected either close button or Enter button
                    /// <summary> User performed cancel operation </summary>
					RESULT_USER_CANCELED,	// User performed cancel operation.
                    /// <summary> IME Dialog operation has been aborted </summary>
					RESULT_ABORTED,			// IME Dialog operation has been aborted.
				}

                /// <summary>
                /// Button pressed to close the IME dialog
                /// </summary>
				public enum EnumImeDialogResultButton
				{
                    /// <summary> IME Dialog operation has been aborted or canceled </summary>
					BUTTON_NONE,	// IME Dialog operation has been aborted or canceled.
                    /// <summary> User selected close button </summary>
					BUTTON_CLOSE,	// User selected close button
                    /// <summary> User selected Enter button </summary>
					BUTTON_ENTER,	// User selected Enter button
				}

                /// <summary>
                /// Structure containing the result of the IME dialog
                /// </summary>
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				public struct ImeDialogResult
				{
                    /// <summary>
                    /// Result of the IME dialog
                    /// </summary>
					public EnumImeDialogResult result;

                    /// <summary>
                    /// Button pressed to close the IME dialog
                    /// </summary>
					public EnumImeDialogResultButton button;

					IntPtr _text;

                    /// <summary>
                    /// Text entered in the IME dialog
                    /// </summary>
					public string text
					{
						get { return Marshal.PtrToStringAnsi(_text); }
					}
				};

				// IME Dialog.
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxImeDialogIsDialogOpen();
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxImeDialogOpen(SceImeDialogParam parameters, SceImeParamExtended extended);
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxImeDialogGetResult(out ImeDialogResult result);

				// Messages.
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogHasMessage();
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogGetFirstMessage(out Dialog.Messages.PluginMessage msg);
				[DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogRemoveFirstMessage();

				/// <summary>
                /// Event handlers.
                /// </summary>
				public static event Dialog.Messages.EventHandler OnGotIMEDialogResult;

				/// <summary>
                /// Is the IME dialog open?
                /// </summary>
				public static bool IsDialogOpen
				{
					get { return PrxImeDialogIsDialogOpen(); }
				}

                /// <summary>
                /// Open the IME dialog with the specified parameters.
                /// </summary>
                /// <param name="Imeparams">The dialog params</param>
                /// <param name="extended">The additional params</param>
                /// <returns>True is IME opened</returns>
				public static bool Open(SceImeDialogParam Imeparams, SceImeParamExtended extended)
				{
					bool ret = PrxImeDialogOpen(Imeparams, extended);
					return ret;
				}

                /// <summary>
                /// Get the result of the IME dialog.
                /// </summary>
                /// <returns>The result of the IME dialog</returns>
				public static ImeDialogResult GetResult()
				{
					ImeDialogResult result = new ImeDialogResult();
					PrxImeDialogGetResult(out result);
					return result;
				}

                /// <summary>
                /// Process messages from the plugin.
                /// </summary>
                /// <param name="msg">The plugin message</param>
				public static void ProcessMessage(Dialog.Messages.PluginMessage msg)
				{
					// Interpret the message and trigger corresponding events.
					switch (msg.type)
					{
						case Dialog.Messages.MessageType.kDialog_GotIMEDialogResult:
						if (OnGotIMEDialogResult != null) OnGotIMEDialogResult(msg);
						break;
					}
				}

                /// <summary>
                /// Initialise the Dialog system.
                /// </summary>
				public static void Initialise()
				{
				}

                /// <summary>
                /// Update the Dialog system, process messages.
                /// </summary>
				public static void Update()
				{
				}
			}
		} // Dialog
	} // PS4
} // Sony
