
using UnityEditor;
using UnityEditor.TestTools;

[RequirePlatformSupport(BuildTarget.PS5)]
public class PS5_DevelopmentBuildTests : BuildTestExpectedPlugin
{
    protected override BuildOptions GetBuildOptions()
    {
        return BuildOptions.Development;
    }

    protected override (BuildTargetGroup, BuildTarget) GetBuildTarget()
    {
        return (BuildTargetGroup.PS5, BuildTarget.PS5);
    }
}

