using System;
using System.IO;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.TestTools;

[RequirePlatformSupport(BuildTarget.StandaloneWindows)]
public class WindowsIl2cpp_BuildTests : BuildTests
{
    ScriptingImplementation m_BeforeBuildBackend;

    [OneTimeSetUp]
    protected override void CreateBuild()
    {
        if (!GetIsIl2CPPInstalled())
        {
            Assert.Ignore("Il2cpp is not installed");
        }
        m_BeforeBuildBackend = PlayerSettings.GetScriptingBackend(NamedBuildTarget.Standalone);
        PlayerSettings.SetScriptingBackend(NamedBuildTarget.Standalone, ScriptingImplementation.IL2CPP);
        base.CreateBuild();
    }

    protected override BuildOptions GetBuildOptions()
    {
        return BuildOptions.None;
    }

    protected override (BuildTargetGroup, BuildTarget) GetBuildTarget()
    {
        return (BuildTargetGroup.Standalone, BuildTarget.StandaloneWindows);
    }

    [OneTimeTearDown]
    public void Reset()
    {
        PlayerSettings.SetScriptingBackend(NamedBuildTarget.Standalone, m_BeforeBuildBackend);
    }

    private static bool GetIsIl2CPPInstalled()
    {
        string il2cppPath = Path.Combine(EditorApplication.applicationContentsPath, "PlaybackEngines", "windowsstandalonesupport", "Variations", "il2cpp");
        return Directory.Exists(il2cppPath);
    }
}
