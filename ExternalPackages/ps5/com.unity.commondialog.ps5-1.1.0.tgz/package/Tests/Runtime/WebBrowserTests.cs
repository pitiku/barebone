﻿using UnityEngine;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;
using System.Threading.Tasks;
using Sony.PS5.Dialog;

class WebBrowserTests
{
    bool dialogClosedReceived = false;

    [OneTimeSetUp]
    public void OneTimeSetup()
    {
        Sony.PS5.Dialog.Main.Initialise();
    }

    [SetUp]
    public void Setup()
    {
        dialogClosedReceived = false;
    }

    [TearDown]
    public void TearDown()
    {
        WebBrowser.OnGotWebBrowserDialogResult -= OnGotWebBrowserResult;
    }

    [Test, Timeout(10000 /*10 seconds*/)]
    public async Task Can_Open_Terminate_ReopenDialog()
    {
        var webBrowserParam = new Sony.PS5.Dialog.WebBrowser.WebBrowserParam();
        webBrowserParam.url = "https://www.playstation.com/country-selector/";
        bool didOpen = Sony.PS5.Dialog.WebBrowser.Open(webBrowserParam);
        Assert.IsTrue(didOpen, "Initial Open failed");
        Main.Update();
        await Task.Delay(33);
        Main.Update();
        Sony.PS5.Dialog.WebBrowser.Terminate();
        Main.Update();

        Assert.IsFalse(WebBrowser.IsDialogOpen);

        Main.Update();
        await Task.Delay(33);
        Main.Update();
        var webBrowserParam2 = new Sony.PS5.Dialog.WebBrowser.WebBrowserParam();
        webBrowserParam2.url = "https://www.playstation.com/country-selector/";
        bool didOpen2 = Sony.PS5.Dialog.WebBrowser.Open(webBrowserParam2);
        Assert.IsTrue(didOpen2,  "Second open failed");
        Main.Update();
        Sony.PS5.Dialog.WebBrowser.Terminate();

        Main.Update();
        Assert.IsFalse(WebBrowser.IsDialogOpen);
    }

    //If the dialog does not close this test will timeout rather than fail
    //If you are seeing a timeout then the dialog is probably not closing properly
    [Test, Timeout(5000 /*5 seconds*/)]
    public async Task Can_CloseDialog()
    {
        var webBrowserParam = new Sony.PS5.Dialog.WebBrowser.WebBrowserParam();
        webBrowserParam.url = "https://www.playstation.com/country-selector/";
        bool didOpen = Sony.PS5.Dialog.WebBrowser.Open(webBrowserParam);
        Assert.IsTrue(didOpen, "Open failed");

        await Task.Delay(33);
        Main.Update();

        bool didClose = WebBrowser.Close();
        Assert.IsTrue(didClose, "Close failed");

        while (WebBrowser.IsDialogOpen == true)
        {
            Main.Update();
            await Task.Delay(33);
        }
    }

    //If the dialog fails to close for any reason this test will timeout
    [Test, Timeout(5000 /*5 seconds*/)]
    [TestCase(WebBrowser.CallbackType.PARAM_TYPE_NONE, null)]
    [TestCase(WebBrowser.CallbackType.PARAM_TYPE_URL, "testscheme:")]
    [TestCase(WebBrowser.CallbackType.PARAM_TYPE_REGEX, "tes.p[a-z]ram$")]
    public async Task OpenWebBrowserDialog_GetResult(WebBrowser.CallbackType callback, string cbURL)
    {
        var webBrowserParam = new Sony.PS5.Dialog.WebBrowser.WebBrowserParam();
        webBrowserParam.url = "https://www.playstation.com/country-selector/";
        webBrowserParam.callbackType = callback;
        webBrowserParam.callbackURL = cbURL;

        WebBrowser.OnGotWebBrowserDialogResult += OnGotWebBrowserResult;
        bool didOpen = Sony.PS5.Dialog.WebBrowser.Open(webBrowserParam);
        Assert.IsTrue(didOpen);

        await Task.Delay(33);

        Sony.PS5.Dialog.WebBrowser.Close();
        await WaitUntilDialogResultReceived();

        var browserResult = WebBrowser.GetResult();
        Assert.AreEqual(WebBrowser.EnumWebBrowserDialogResult.RESULT_OK, browserResult.result);
    }

    async Task WaitUntilDialogResultReceived()
    {
        while (!dialogClosedReceived)
        {
            Debug.Log($"F{Time.frameCount} :: Waiting for results..");
            Main.Update();
            await Task.Delay(33);
        }
    }

    void OnGotWebBrowserResult(Messages.PluginMessage msg)
    {
        Debug.Log("Got Web Browser Results!");
        dialogClosedReceived = true;
    }
}
