# Changelog

## [1.0.1] - 2026-02-26

### Changed
- Update for internal changes to the core package.
- Bumped package dependency versions for latest SDK support.

### Fixed
- Fixed an issue where the input pairing system's events did not align to similar ones found in the Input System package. When the Input System package is in-use, Platform Toolkit now hooks up to these events to synchronize them.


## [1.0.0] - 2025-11-03
- Initial release
