using System.Collections.Generic;
using Unity.PlatformToolkit.Editor;
using UnityEditor;

namespace Unity.PlatformToolkit.PS5.Editor
{
    internal class PS5SupportDeclaration : IPlatformToolkitSupportDeclaration
    {
        private static readonly PS5SettingsProvider s_Provider = new PS5SettingsProvider();

        private static readonly BuildTarget[] k_SupportedBuildTargets = new[]
        {
            BuildTarget.PS5
        };

        public string DisplayName => "PlayStation®5";
        public string Key => PS5PlatformToolkit.Key;

        public IReadOnlyCollection<BuildTarget> SupportedPlatforms => k_SupportedBuildTargets;

        public IPlatformToolkitSettingsProvider SettingsProvider => s_Provider;

        public IPlatformToolkitBuilder CreateBuilder(IAchievementConfigurationContext achievementContext = null,
            ISettingsConfigurationContext settingsContext = null)
        {
            var settings = (PS5Settings)SettingsProvider.CreateSettingsConfiguration(settingsContext).Settings;
            return new PS5Builder(achievementContext, settings);
        }

        public bool AchievementsSupported => true;
        public IAchievementConfiguration CreateAchievementConfiguration(IAchievementConfigurationContext context)
        {
            return new AchievementConfigurationWithStringId(context, DisplayName, Key);
        }
    }
}
