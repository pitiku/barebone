namespace Unity.PlatformToolkit.PS5.Editor
{
    /// <summary>Values related to the PS5 Platform Toolkit implementation.</summary>
    public static class PS5PlatformToolkit
    {
        /// <summary>Key used to identify the PS5 Platform Toolkit implementation.</summary>
        public const string Key = "Unity.Playstation5";
    }
}
