* [Platform Toolkit package for PlayStation®5](index.md)
    * [Get started with Platform Toolkit for PS5](get-started-with-pt-for-ps5.md)
    * [PS5 account attributes reference](account-attributes.md)
    * [Platform-specific reference](platform-details.md)