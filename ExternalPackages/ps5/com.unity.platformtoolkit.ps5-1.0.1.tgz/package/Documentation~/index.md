# Platform Toolkit package for PlayStation®5

This package provides integration between the Platform Toolkit package and PlayStation®5 (PS5).

> [!NOTE]
> The Platform Toolkit PS5 package can help in the development of your PS5 title. However, use of the toolkit doesn't automatically ensure compliance with all [PlayStation®5 TRC requirements](https://game.develop.playstation.net/resources/documents/TRC/latest/TRC/__toc.html). You must verify that your title meets all of these requirements before submission.

|**Topic**|**Description**|
|---|---|
|[Get started with Platform Toolkit for PS5](get-started-with-pt-for-ps5.md)|Instructions to set up your Unity project for PS5 with the Platform Toolkit package.|
|[PS5 account attributes reference](account-attributes.md)|Reference for the attributes available on PS5 accounts.|
|[Platform-specific reference](platform-details.md)|Understand specific details about using the Platform Toolkit package with PS5.|