using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Unity.SaveData.PS5;
using Unity.SaveData.PS5.Core;
using Unity.SaveData.PS5.Delete;
using Unity.SaveData.PS5.Info;
using Unity.SaveData.PS5.Mount;
using Unity.SaveData.PS5.Search;

namespace Unity.PlatformToolkit.PS5
{
    internal static class PS5SavingTaskWrapper
    {
        private static bool m_IsInitialized = false;

        public static Task<Mounting.MountResponse> Mount(Mounting.MountRequest request)
        {
            SubscribeToAsyncFileOperationCallback();
            var response = new PS5TaskWrapperMountResponse();

            try
            {
                Mounting.Mount(request, response);
                return response.TaskCompletionSource.Task;
            }
            catch (SaveDataException e)
            {
                response.TaskCompletionSource.SetException(e);
                return response.TaskCompletionSource.Task;
            }
        }

        public static Task WriteFile(PS5TaskWrapperWriteFileRequest request)
        {
            SubscribeToAsyncFileOperationCallback();

            PS5TaskWrapperWriteFileResponse response = new PS5TaskWrapperWriteFileResponse();
            try
            {
                FileOps.CustomFileOp(request, response);
                return response.TaskCompletionSource.Task;
            }
            catch (SaveDataException e)
            {
                response.TaskCompletionSource.SetException(e);
                return response.TaskCompletionSource.Task;
            }
        }

        public static Task DeleteDirectory(Deleting.DeleteRequest request)
        {
            SubscribeToAsyncFileOperationCallback();
            PS5TaskWrapperEmptyResponse response = new PS5TaskWrapperEmptyResponse();
            try
            {
                Deleting.Delete(request, response);
                return response.TaskCompletionSource.Task;
            }
            catch (SaveDataException e)
            {
                response.TaskCompletionSource.SetException(e);
                return response.TaskCompletionSource.Task;
            }
        }

        public static Task<byte[]> ReadFile(PS5TaskWrapperReadFileRequest request)
        {
            SubscribeToAsyncFileOperationCallback();
            PS5TaskWrapperReadFilesResponse response = new PS5TaskWrapperReadFilesResponse();
            try
            {
                FileOps.CustomFileOp(request, response);
                return response.TaskCompletionSource.Task;
            }
            catch (SaveDataException e)
            {
                response.TaskCompletionSource.SetException(e);
                return response.TaskCompletionSource.Task;
            }
        }

        public static Task DeleteFile(PS5TaskWrapperDeleteFileRequest request)
        {
            SubscribeToAsyncFileOperationCallback();
            PS5TaskWrapperDeleteFileResponse response = new PS5TaskWrapperDeleteFileResponse();
            try
            {
                FileOps.CustomFileOp(request, response);
                return response.TaskCompletionSource.Task;
            }
            catch (SaveDataException e)
            {
                response.TaskCompletionSource.SetException(e);
                return response.TaskCompletionSource.Task;
            }
        }

        public static Task<IEnumerable<string>> EnumerateFiles(PS5TaskWrapperEnumerateFilesRequest request)
        {
            SubscribeToAsyncFileOperationCallback();

            PS5EnumerateFileResponse response = new PS5EnumerateFileResponse();
            try
            {
                FileOps.CustomFileOp(request, response);
                return response.TaskCompletionSource.Task;
            }
            catch (SaveDataException e)
            {
                response.TaskCompletionSource.SetException(e);
                return response.TaskCompletionSource.Task;
            }
        }

        public static Task<string[]> EnumerateArchives(Searching.DirNameSearchRequest request)
        {
            SubscribeToAsyncFileOperationCallback();

            PS5TaskWrapperEnumerateArchivesResponse response = new PS5TaskWrapperEnumerateArchivesResponse();
            try
            {
                Searching.DirNameSearch(request, response);
                return response.TaskCompletionSource.Task;
            }
            catch (SaveDataException e)
            {
                response.TaskCompletionSource.SetException(e);
                return response.TaskCompletionSource.Task;
            }
        }

        public static Task Unmount(Mounting.UnmountRequest request)
        {
            SubscribeToAsyncFileOperationCallback();

            PS5TaskWrapperEmptyResponse response = new PS5TaskWrapperEmptyResponse();
            try
            {
                Mounting.Unmount(request, response);
                return response.TaskCompletionSource.Task;
            }
            catch (SaveDataException e)
            {
                response.TaskCompletionSource.SetException(e);
                return response.TaskCompletionSource.Task;
            }
        }

        public static Task<ulong> GetAvailableSpace(Searching.DirNameSearchRequest request)
        {
            PS5TaskWrapperAvailableSpaceResponse response = new PS5TaskWrapperAvailableSpaceResponse();
            try
            {
                Searching.DirNameSearch(request, response);
                return response.TaskCompletionSource.Task;
            }
            catch (SaveDataException e)
            {
                response.TaskCompletionSource.SetException(e);
                return response.TaskCompletionSource.Task;
            }
        }

        private static void SubscribeToAsyncFileOperationCallback()
        {
            if (m_IsInitialized) return;
            if (!m_IsInitialized)
            {
                Main.OnAsyncEvent += OnAsyncFileOperationEvent;
                m_IsInitialized = true;
            }
        }

        /// <summary>
        /// This method is required by PS5 and is invoked by "The system" when a file operation is completed.
        /// Optionally, it also contains the data that you've just written.
        ///
        /// The flow works as follows: You create a Request and a Response, then execute the request with the response as argument.
        /// Then this method is invoked (By the system) with the response containing the data (If any)
        /// </summary>
        /// <param name="callbackEvent">The response to the file request, containing the files</param>
        private static void OnAsyncFileOperationEvent(SaveDataCallbackEvent callbackEvent)
        {
            if (callbackEvent.Response is PS5TaskWrapperMountResponse mountingResponse)
            {
                if (mountingResponse.ReturnCode == ReturnCodes.SUCCESS)
                {
                    mountingResponse.TaskCompletionSource.SetResult(mountingResponse);
                }
                else
                {
                    mountingResponse.TaskCompletionSource.SetException(
                        new PS5SaveDataException(callbackEvent.Response.ReturnCode));
                }

                return;
            }

            if (callbackEvent.Response is PS5TaskWrapperWriteFileResponse fileResponse)
            {
                if (fileResponse.Exception != null)
                {
                    fileResponse.TaskCompletionSource.SetException(fileResponse.Exception);
                    return;
                }

                fileResponse.TaskCompletionSource.SetResult(true);
                return;
            }

            if (callbackEvent.Response is PS5TaskWrapperReadFilesResponse readFileResponse)
            {
                if (readFileResponse.fileData == null)
                {
                    readFileResponse.TaskCompletionSource.SetResult(null);
                }
                else
                {
                    readFileResponse.TaskCompletionSource.SetResult(readFileResponse.fileData);
                }

                return;
            }

            // Deleting a file
            if (callbackEvent.Request is PS5TaskWrapperDeleteFileRequest &&
                callbackEvent.Response is PS5TaskWrapperDeleteFileResponse deleteFileEmptyResponse)
            {
                if (deleteFileEmptyResponse.ReturnCode == ReturnCodes.SUCCESS)
                {
                    // TODO: When deleting do we need to check how much space we have left again?
                    deleteFileEmptyResponse.TaskCompletionSource.SetResult(true);
                }
                else
                {
                    deleteFileEmptyResponse.TaskCompletionSource.SetException(
                        new Exception(deleteFileEmptyResponse.ReturnCode.ToString()));
                }

                return;
            }

            // Deleting a folder / archive
            if (callbackEvent.Request is Deleting.DeleteRequest &&
                callbackEvent.Response is PS5TaskWrapperEmptyResponse response)
            {
                if (response.ReturnCode == ReturnCodes.SUCCESS)
                {
                    response.TaskCompletionSource.SetResult(true);
                }
                else
                {
                    response.TaskCompletionSource.SetException(new Exception(response.ReturnCode.ToString()));
                }

                return;
            }

            if (callbackEvent.Response is PS5EnumerateFileResponse enumerateFileResponse)
            {
                if (enumerateFileResponse.Result == null || enumerateFileResponse.Result.Length == 0)
                {
                    enumerateFileResponse.TaskCompletionSource.SetResult(Array.Empty<string>());
                }
                else
                {
                    enumerateFileResponse.TaskCompletionSource.SetResult(enumerateFileResponse.Result);
                }

                return;
            }

            if (callbackEvent.Response is PS5TaskWrapperEnumerateArchivesResponse enumerateArchivesResponse)
            {
                if (enumerateArchivesResponse.SaveDataItems == null ||
                    enumerateArchivesResponse.SaveDataItems.Length == 0)
                {
                    enumerateArchivesResponse.TaskCompletionSource.SetResult(Array.Empty<string>());
                }
                else
                {
                    enumerateArchivesResponse.TaskCompletionSource.SetResult(enumerateArchivesResponse.SaveDataItems
                        .Select(item => item.DirName.Data).ToArray());
                }

                return;
            }

            if (callbackEvent.Response is PS5TaskWrapperAvailableSpaceResponse spaceResponse)
            {
                if (spaceResponse.ReturnCode == ReturnCodes.SUCCESS)
                {
                    if (spaceResponse.SaveDataItems != null && spaceResponse.SaveDataItems.Length > 0)
                    {
                        ulong amountOfBlocksFree = 0;
                        ulong totalAmountOfBlocks = 0;
                        if (spaceResponse.HasInfo)
                        {
                            foreach (var item in spaceResponse.SaveDataItems)
                            {
                                amountOfBlocksFree += item.Info.FreeBlocks;
                                totalAmountOfBlocks += item.Info.Blocks;
                            }
                        }

                        var usedBlocks = totalAmountOfBlocks - amountOfBlocksFree;
                        ulong bytesFree = usedBlocks * Mounting.MountRequest.BLOCK_SIZE;
                        spaceResponse.TaskCompletionSource.SetResult(bytesFree);
                    }
                    else
                    {
                        spaceResponse.TaskCompletionSource.SetResult(Mounting.MountRequest.BLOCKS_MAX *
                                                                     Mounting.MountRequest.BLOCK_SIZE);
                    }
                }
            }

            if (callbackEvent.Request is Mounting.UnmountRequest &&
                callbackEvent.Response is PS5TaskWrapperEmptyResponse unmountEmptyResponse)
            {
                if (unmountEmptyResponse.ReturnCode == ReturnCodes.SUCCESS)
                {
                    unmountEmptyResponse.TaskCompletionSource.SetResult(true);
                }
                else
                {
                    unmountEmptyResponse.TaskCompletionSource.SetException(
                        new PS5SaveDataException(unmountEmptyResponse.ReturnCode));
                }

                return;
            }
        }
    }
}
