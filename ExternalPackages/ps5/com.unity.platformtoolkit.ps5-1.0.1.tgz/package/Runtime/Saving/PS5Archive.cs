using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System.IO;
using System;
using Unity.SaveData.PS5.Mount;

namespace Unity.PlatformToolkit.PS5
{
    internal class PS5Archive : AbstractArchive
    {
        private readonly int m_UserID;
        private bool m_SaveExists;

        private readonly string m_SaveName;
        private IReadOnlyList<string> m_Files;
        private Mounting.MountPoint m_MountPoint;

        public PS5Archive(int userID, string archiveName)
             : base(doDataBuffering: true)
        {
            m_UserID = userID;
            m_SaveName = archiveName;
        }

        public async Task Initialize(bool saveExists)
        {
            m_SaveExists = saveExists;
            if (saveExists)
            {
                var mountRequest =
                    PS5RequestHelper.CreatePS5MountingRequest(m_UserID, m_SaveName, readWrite: false, PS5PlatformToolkit.MaxSaveSizeInBytes);
                var response = await PS5SavingTaskWrapper.Mount(mountRequest);
                m_MountPoint = response.MountPoint;

                var enumerateFileRequest = new PS5TaskWrapperEnumerateFilesRequest(m_UserID, m_MountPoint);
                m_Files = (await PS5SavingTaskWrapper.EnumerateFiles(enumerateFileRequest)).ToList();

                if (m_Files.Count == 0)
                {
                    var unMountRequest =
                        PS5RequestHelper.CreatePS5UnmountRequest(m_UserID,m_MountPoint.PathName,commitData: false);
                    await PS5SavingTaskWrapper.Unmount(unMountRequest);
                    throw new CorruptedSaveException("Corrupted save found, no files are in the save");
                }
            }

            if (m_Files == null)
                m_Files = new List<string>();
        }

        public override Task<IReadOnlyList<string>> EnumerateFiles()
        {
            return Task.FromResult(m_Files);
        }

        protected override async Task<byte[]> GetDataFromStorage(string name)
        {
            if (!m_SaveExists)
            {
                throw new FileNotFoundException($"Save does not exist: {name}");
            }

            var request =
                new PS5TaskWrapperReadFileRequest(m_UserID, m_MountPoint.PathName, name);
            var data = await PS5SavingTaskWrapper.ReadFile(request);

            if (data == null)
            {
                throw new FileNotFoundException($"File not found: {name}");
            }

            return data;
        }

        protected override async Task CommitDataToStorage(IReadOnlyCollection<(string name, byte[] data)> writtenFiles,
            IReadOnlyCollection<string> deletedFiles)
        {
            if (m_MountPoint != null)
            {
                var unmountRequest = PS5RequestHelper.CreatePS5UnmountRequest(m_UserID, m_MountPoint.PathName, commitData: false);
                await PS5SavingTaskWrapper.Unmount(unmountRequest);
                m_MountPoint = null;
            }

            var mountRequest =
                PS5RequestHelper.CreatePS5MountingRequest(m_UserID, m_SaveName, readWrite: true, PS5PlatformToolkit.MaxSaveSizeInBytes);
            var response = await PS5SavingTaskWrapper.Mount(mountRequest);
            m_MountPoint = response.MountPoint;

            try
            {
                foreach (var writtenFile in writtenFiles)
                {
                    var request = new PS5TaskWrapperWriteFileRequest(m_UserID, m_MountPoint.PathName, writtenFile.name,
                        writtenFile.data);
                    await PS5SavingTaskWrapper.WriteFile(request);
                }

                foreach (var deletedFileName in deletedFiles)
                {
                    var request = new PS5TaskWrapperDeleteFileRequest(m_UserID, m_MountPoint.PathName, deletedFileName);
                    await PS5SavingTaskWrapper.DeleteFile(request);
                }

                ExceptionTesting.TriggerException(ExceptionPoint.PreCommit);
            }
            catch (Exception)
            {
                var unmountNoCommitRequest =
                    PS5RequestHelper.CreatePS5UnmountRequest(m_UserID, m_MountPoint.PathName, commitData: false);
                await PS5SavingTaskWrapper.Unmount(unmountNoCommitRequest);

                if (!m_SaveExists)
                {
                    ExceptionTesting.TriggerException(ExceptionPoint.NewSaveCommitFailureCleanup);
                    var directoryDeletionRequest = PS5RequestHelper.CreatePS5DeleteDirectoryRequest(m_UserID, m_MountPoint.DirName.Data);
                    await PS5SavingTaskWrapper.DeleteDirectory(directoryDeletionRequest);
                }

                m_MountPoint = null;
                throw;
            }

            var unmountCommitRequest =
                PS5RequestHelper.CreatePS5UnmountRequest(m_UserID, m_MountPoint.PathName, commitData: true);
            await PS5SavingTaskWrapper.Unmount(unmountCommitRequest);
            //Dispose method could be called after this so we should not have a mount point available.
            m_MountPoint = null;
        }

        public override async ValueTask DisposeAsync()
        {
            if (m_MountPoint != null && m_MountPoint.IsMounted)
            {
                var unmountRequest = PS5RequestHelper.CreatePS5UnmountRequest(m_UserID, m_MountPoint.PathName, commitData: false);
                await PS5SavingTaskWrapper.Unmount(unmountRequest);
            }

            m_MountPoint = null;
            await base.DisposeAsync();
        }

        public override void Dispose()
        {
            if (m_MountPoint != null && m_MountPoint.IsMounted)
            {
                var unmountRequest = PS5RequestHelper.CreatePS5UnmountRequest(m_UserID, m_MountPoint.PathName, commitData: false);
                PS5SavingTaskWrapper.Unmount(unmountRequest).GetAwaiter().GetResult();
            }

            m_MountPoint = null;
            base.Dispose();
        }

        protected override Task WriteDataToStorage(string name, byte[] data)
        {
            // Not used anymore
            return Task.CompletedTask;
        }

        protected override void RemoveDataFromStorage(string name)
        {
            // Not used anymore
        }
    }
}
