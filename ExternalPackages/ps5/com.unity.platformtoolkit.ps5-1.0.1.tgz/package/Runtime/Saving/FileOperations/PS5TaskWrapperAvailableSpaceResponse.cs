using System.Threading.Tasks;
using Unity.SaveData.PS5.Search;

namespace Unity.PlatformToolkit.PS5
{
    internal class PS5TaskWrapperAvailableSpaceResponse : Searching.DirNameSearchResponse
    {
        public readonly TaskCompletionSource<ulong> TaskCompletionSource = new TaskCompletionSource<ulong>();
    }
}
