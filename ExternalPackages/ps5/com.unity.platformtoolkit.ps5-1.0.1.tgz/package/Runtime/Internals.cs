using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.PlatformToolkit.PS5.Tests")]
[assembly: InternalsVisibleTo("Unity.PlatformToolkit.PS5.Editor")]
