#pragma comment (lib, "SceUserService_stub_weak")

#include "user_service.h"
