
# Links to Sony documentation

For more information about how to work with save data, see the following documentation on the PlayStation® Developer network:

| Feature | Link |
| ------- | ---- |
| Main Page | [SaveData Library Overview](https://game.develop.playstation.net/resources/documents/SDK/latest/SaveData-Overview/__toc.html) |
| Initialization | [Initialization/Termination](https://game.develop.playstation.net/resources/documents/SDK/latest/SaveData-Reference/0005.html) |
| Mounting | [Mounting/Unmounting](https://game.develop.playstation.net/resources/documents/SDK/latest/SaveData-Reference/0011.html) |
| Deleting | [Save Data Deletion](https://game.develop.playstation.net/resources/documents/SDK/latest/SaveData-Reference/0021.html) |
| Backup | [Backup](https://game.develop.playstation.net/resources/documents/SDK/latest/SaveData-Reference/0037.html) |
| Searching | [Save Data Search](https://game.develop.playstation.net/resources/documents/SDK/latest/SaveData-Reference/0033.html) |
| Dialogs | [SaveDataDialog Library Overview](https://game.develop.playstation.net/resources/documents/SDK/latest/SaveDataDialog-Overview/__toc.html) |
