# Changelog
All notable changes to the package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

Due to package verification, the latest version below is the unpublished version and the date is meaningless.
however, it has to be formatted properly to pass verification tests.
## [1.4.0] - 2026-02-11

### Removed
- Removed Backup functionality in SDK 13.00 that is now removed from the SDK. Calling backup in SDK 13.00 will result in an error result.

## [1.3.1] - 2026-01-15

### Fixed
- Fixed a case where an operation could throw a managed exception but have a SUCCESS return code. Instead an operation that fails because of a managed exception will return the error code ManagedException (0x8A000002)

## [1.3.0] - 2025-10-23

### Added
- Added support for cancallation flag in mounting and unmounting to cancel without saving the files.

## [1.2.0] - 2025-10-22

### Added
- Added support for supplying OptionFlag.EnableDelete to OptionParam for a Dialog. This enables the deletion of Save Data from a Load/Save Dialog
- Added IsSaveDataDeleted to DialogResult to retreive if a Save data has been deleted in a Dialog
- Added ItemCountToSuppressVisibility to NewItem for a Dialog. This will hide the New Item if the number of existing Save Data's exceeds this value

### Changed
- Signature files have been updated
- Updated XML documentation for all public APIs.
- Updated to support SDK 12

### Fixed
- Fixed a bug that caused the native PRX to fail to recompile when upgrading to a new package .tgz.

### Removed
- The following types and functions have been marked as obsolete. These types refer to SDK Features that have been deprecated and are not recommended for new submissions. These features will be removed from the SDK in SDK 13.00 and removed from the package in the next package version after the release of SDK 13.00. Types and functions marked as obsolete: Backups, Backup(), FunctionTypes.Backup, FunctionTypes.NotificationUnmountWithBackup, FunctionTypes.NotificationUnmountWithBackup, MountModeFlags.DestructOff, MountModeFlags.BackupAsync.
- Backups have been removed from the Sample.

## [1.1.4] - 2024-08-22

### Fixed
- Fixed a linker error that could occour on recent Unity versions

## [1.1.3] - 2024-04-16

### Fixed
- Fixed a null reference exception that could occur when creating a build for Windows IL2CPP in 2021.3

### Added
- Added support for Commit and BackupAsync UnmountMode in unmounting of saves
- Added comments explaining that backups will not be created if rollback is enabled

## [1.1.2] - 2024-02-26

### Fixed
- Fixed a infinite build loop that could occur when an error was thrown during serialization (e.g shader compilation)

## [1.1.1] - 2024-01-10

### Fixed
   - Fixed an issue where the pacakge would invalidate the PackageCache when building and the package was added from a UMP Server
   - Fixed an issue where absoulte paths in the generated cpp would dirty source control when no cotents of the file has changed
   - Fixed an issue where compiling for PS5 when PS5 was not the selected platform would result in the package PRX (or cpp replacement) not being generated

### Changed
   - Instead of a pre-processed cpp source file generated in the package folder, the package now generates a prx in the Library/SoruceGeneratedPlugins folder which is added to the build

## [1.1.0] - 2023-11-09

### Added
   - Added support for showing other titles SaveData in the Load List Dialog (Items.TitleId)
   - Added support for specifiying OptionParam Flags in SaveData dialogs (Options.Flag), currently used to show PS4 SaveData
   - Added test PS4 Load Dialog to Sample Project (Dialogs > Test Dialog Methods > PS4 Load List Dialog)

## [1.0.1] - 2023-10-18

### Fixed
   - Stop editor build script executing when an non-PlayStation platform is being built
   
## [1.0.0] - 2023-09-04
   - New package format.

## [0.0.16-preview] - 2023-04-06

### Added
   - Added support for SDK 7.0

## [0.0.15-preview] - 2022-08-10

### Fixed
   - Added support for SDK 6.00

## [0.0.14-preview] - 2022-08-10

### Fixed
   - Changed MountRequest() constructor so it can now be called from a C# thread other than just the Unity main thread.

## [0.0.13-preview] - 2022-05-23

### Changed
   - Included offline HTML documentation in the HTMLDocs~ folder. Documentation can now be viewed without needing to run a local webserver.

## [0.0.12-preview] - 2022-04-25

### Added
   - Added support for SDK 5.0. Exposed MountRequest.SystemBlocks to enable support for new rollback feature (enabled by default)

## [0.0.11-preview] - 2021-11-23

### Changed
   - Added support for SDK 4.0

## [0.0.10-preview] - 2021-05-25

### Changed
   - Added support to read PS4 save games on PS5 (SDK 3.0 only)

## [0.0.9-preview] - 2021-02-17

### Changed
   - Updated the sample ExampleWriteFilesRequest and ExampleReadFilesRequest to demonstrate more efficient C# methods to write save files on PS5.

## [0.0.8-preview] - 2021-01-08

### Added
   - New package documentation and HTML pages updated
   
### Changed
   - Fixed spelling of Unity.SaveData.PS5.Initalization. Changed to Unity.SaveData.PS5.Initialization.
   - Updated MountRequest.BLOCK_SIZE, MountRequest.BLOCKS_MIN  and MountRequest.BLOCKS_MAX to new PS5 SDK values
   
### Fixed
   - Error checks are performed when setting SaveDataParams properties Title, SubTitle and Detail.
       * The byte length of the string is checked and an exception thrown if it exceeds the maximum supported length.

## [0.0.7-preview] - 2020-11-10

### Added
   - Added additional support for SDK 2.0 on PS5
      * Moved existing .prx files to plugin folders 1_00
	  * Added new .prx files to plugin folders 2_00

## [0.0.6-preview] - 2020-09-17

### Changed
- Added AllowNewItemTest callback to StartSaveDialogProcess. Use this to decide if the save dialog should display a save new item button.

## [0.0.5-preview] - 2020-09-14

### Changed
- Rebuilt SaveData.prx using SDK 1.000.050

## [0.0.4-preview] - 2020-03-05

### Changed

- Updated to use SDK 0.95
- Changed namespace to match package name `Unity.SaveData.PS5`
- Split system into additional namespaces to group functionality and produce better documentation
- Fixed issue in native code with sceSaveDataMount3 using SCE_SAVE_DATA_MOUNT_MODE_RDWR as usage has changed in 0.95. No change to the C# API was required.

### Added

- Added HTML documentation to HTML~ directory in package root.

## [0.0.3-preview] - 2020-02-17

### Added

- HTML offline documentation. HTML docs are located in the /HTMLDocs~ directory.

## [0.0.2-preview] - 2020-02-17

### Added

- Test sample now added to package. Installed from Package Manager Window

## [0.0.1-preview] - 2020-01-10

### Fixed

- Initial Version

### Changed

- Initial Version

### Added

- Initial Version



 
  





