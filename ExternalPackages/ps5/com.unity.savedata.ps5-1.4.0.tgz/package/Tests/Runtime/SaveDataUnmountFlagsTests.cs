using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Unity.SaveData.PS5.Core;
using Unity.SaveData.PS5.Info;
using Unity.SaveData.PS5.Mount;
using UnityEngine;
using UnityEngine.TestTools;

namespace SaveDataTests
{
    public class SaveDataUnmountFlagsTests : BaseTestFramework
    {
        private readonly string k_DirName = "testdir";
        private readonly string k_FileName = "testfile";
        private readonly byte[] k_Data = Encoding.ASCII.GetBytes("helloworld");

        [UnityTest, Description("Test writing file cancellation does not save file")]
        [Ignore("Tests depend on each other, adding this will fail. See ticket: PLAT-16758")]
        public IEnumerator UnmountShouldNotSaveFiles()
        {
            yield return new WaitUntil(IsInitialized);
            // 1. Mounting with cancel flag
            var loggedInUser = GetUser();
            var mountRequest =
                CreateMountingRequest(loggedInUser.userId, k_DirName, true, Mounting.PrepareMode.EnableCancel);
            var mountResponse = new Mounting.MountResponse();
            Mounting.Mount(mountRequest, mountResponse);
            yield return new WaitUntil(() => mountResponse.Locked == false);

            // 2. Write files
            var writeFileRequest = new WriteFilesRequest(loggedInUser.userId, mountResponse.MountPoint.PathName, k_FileName, k_Data);
            var writeFileResponse = new WriteFileResponse();
            FileOps.CustomFileOp(writeFileRequest, writeFileResponse);
            yield return new WaitUntil(() => writeFileResponse.Locked == false);

            // 3. Unmount with cancellation token
            var unmountRequest = CreateUnmountingRequest(loggedInUser.userId, mountResponse.MountPoint.PathName,
                Mounting.UnmountMode.Cancel);
            var unmountResponse = new EmptyResponse();
            Mounting.Unmount(unmountRequest, unmountResponse);
            yield return new WaitUntil(() => unmountResponse.Locked == false);

            // 4. Mount with read only access
            var mountRequestReadOnly =
                CreateMountingRequest(loggedInUser.userId, k_DirName, false, Mounting.PrepareMode.Default);
            var mountResponseReadOnly = new Mounting.MountResponse();
            Mounting.Mount(mountRequestReadOnly, mountResponseReadOnly);
            yield return new WaitUntil(() => mountResponseReadOnly.Locked == false);

            // 5. Check if any file have been written
            var searchRequest = new SearchFilesRequest(loggedInUser.userId, mountResponse.MountPoint);
            var searchResponse = new ReadFilesResponse();
            FileOps.CustomFileOp(searchRequest, searchResponse);
            yield return new WaitUntil(() => searchResponse.Locked == false);
            var items = searchResponse.Result;
            Assert.That(items, Has.Length);
            Assert.That(items.Length, Is.Zero);

            // 6. Unmount just in case
            var unmountRequestReadOnly = CreateUnmountingRequest(loggedInUser.userId, mountResponse.MountPoint.PathName,
                Mounting.UnmountMode.Default);
            var unmountResponseReadOnly = new EmptyResponse();
            Mounting.Unmount(unmountRequestReadOnly, unmountResponseReadOnly);
            yield return new WaitUntil(() => unmountResponseReadOnly.Locked == false);
        }

        private Mounting.UnmountRequest CreateUnmountingRequest(int userID,
            Mounting.MountPointName mountPointName, Mounting.UnmountMode unmountMode)
        {
            return new Mounting.UnmountRequest
            {
                UserId = userID,
                Async = false,
                MountPointName = mountPointName,
                UnmountMode = unmountMode
            };
        }

        private Mounting.MountRequest CreateMountingRequest(int userID, string dirName, bool readWrite, Mounting.PrepareMode prepareMode)
        {
            DirName PS5DirName = new DirName
            {
                Data = dirName,
            };

            return new Mounting.MountRequest
            {
                UserId = userID,
                Async = false,
                DirName = PS5DirName,
                MountMode = readWrite
                    ? Mounting.MountModeFlags.Create2 | Mounting.MountModeFlags.ReadWrite
                    : Mounting.MountModeFlags.ReadOnly,
                PrepareMode = prepareMode,
                Blocks = Mounting.MountRequest.BLOCKS_MIN
            };
        }
    }

    public class SearchFilesRequest : FileOps.FileOperationRequest
    {
        // This pattern searches for every file within the folder, with any extension.
        private readonly string m_SearchPattern = "*.*";

        public SearchFilesRequest(int userID, Mounting.MountPoint mountPoint)
        {
            UserId = userID;
            MountPointName = mountPoint.PathName;
        }

        public override void DoFileOperations(Mounting.MountPoint mountPoint, FileOps.FileOperationResponse response)
        {
            ReadFilesResponse readFileResponse = response as ReadFilesResponse;
            // We expect only the file name, not folder name + file name. So we get the file name only.
            var fullPathFiles = Directory.GetFiles(mountPoint.PathName.Data, m_SearchPattern, SearchOption.AllDirectories);
            readFileResponse.Result = fullPathFiles.Select(file => Path.GetFileName(file)).ToArray();
        }
    }

    public class WriteFilesRequest : FileOps.FileOperationRequest
    {
        private readonly string m_FileName;
        private readonly byte[] m_Data;

        public WriteFilesRequest(int userID, Mounting.MountPointName mountPointName, string fileName, byte[] dataToWrite)
        {
            m_FileName = fileName;
            m_Data = dataToWrite;
            UserId = userID;
            MountPointName = mountPointName;
        }

        public override void DoFileOperations(Mounting.MountPoint mountPoint, FileOps.FileOperationResponse response)
        {
            var savePath = Path.Combine(mountPoint.PathName.Data, m_FileName);
            File.WriteAllBytes(savePath, m_Data);

            WriteFileResponse fileResponse = response as WriteFileResponse;
            FileInfo fileInfo = new FileInfo(savePath);
            fileResponse.lastWriteTime = fileInfo.LastWriteTime;
            fileResponse.totalFileSizeWritten += fileInfo.Length;
        }
    }

    public class ReadFilesResponse : FileOps.FileOperationResponse
    {
        public string[] Result;
    }

    public class WriteFileResponse : FileOps.FileOperationResponse
    {
        public DateTime lastWriteTime;
        public long totalFileSizeWritten;
    }
}
