using System.Collections;
using System.Threading.Tasks;
using NUnit.Framework;
using Unity.SaveData.PS5;
using Unity.SaveData.PS5.Core;
using Unity.SaveData.PS5.Dialog;
using Unity.SaveData.PS5.Initialization;
using UnityEngine;
using UnityEngine.TestTools;

public class DialogTests
{
    int userId = UnityEngine.PS5.Utility.initialUserId;

    [OneTimeSetUp]
    public void Setup()
    {
        Main.Initialize(new InitSettings()
        {
            Affinity = ThreadAffinity.Core5
        });

        Main.OnAsyncEvent += MainOnOnAsyncEvent;
    }

    [OneTimeTearDown]
    public void Cleanup()
    {
        Main.Terminate();
    }

    void MainOnOnAsyncEvent(SaveDataCallbackEvent npevent)
    {

    }

    [Test]
    [TestCase(Dialogs.OptionFlag.Default, null)]
    [TestCase(Dialogs.OptionFlag.Default, 1)]
    [TestCase(Dialogs.OptionFlag.EnableDelete, null)]
    [TestCase(Dialogs.OptionFlag.EnableDelete, 1)]
    public async Task CanOpenSaveDialog(Dialogs.OptionFlag optionFlag, int? limitToSupressNewItem)
    {
        Dialogs.OpenDialogRequest request = new Dialogs.OpenDialogRequest();

        Dialogs.NewItem newItem = new Dialogs.NewItem()
        {
            Title = "Test New Item!"
        };

        request.UserId = userId;
        request.Mode = Dialogs.DialogMode.List;
        request.DispType = Dialogs.DialogType.Save;
        request.Animations = new Dialogs.AnimationParam(Dialogs.Animation.Off, Dialogs.Animation.On);
        request.NewItem = newItem;
        request.Option = new Dialogs.OptionParam()
        {
            Flag = optionFlag
        };

        if (limitToSupressNewItem != null)
        {
            request.NewItem.ItemCountToSuppressVisibility = limitToSupressNewItem.Value;
        }

        request.IgnoreCallback = true;

        var response = new Dialogs.OpenDialogResponse();
        Dialogs.OpenDialog(request, response);

        await Task.Delay(100);

        Dialogs.Close(new Dialogs.CloseParam());

        while (response.Locked)
        {
            await Task.Delay(33);
        }

        /* When closing the Dialog with Close the expected returned values
         are OK and Button Invalid
         */
        Assert.AreEqual(ReturnCodes.SUCCESS, response.ReturnCode);
        Assert.AreEqual(Dialogs.DialogCallResults.OK, response.Result.CallResult);
        Assert.AreEqual(Dialogs.DialogButtonIds.Invalid, response.Result.ButtonId);
        Assert.AreEqual(false, response.Result.IsSaveDataDeleted);
    }
}
