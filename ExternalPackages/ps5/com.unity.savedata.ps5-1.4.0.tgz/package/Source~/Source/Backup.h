#ifndef _BACKUP_H
#define _BACKUP_H

#include "../Includes/PluginCommonIncludes.h"
#include "Core.h"

namespace SaveData
{
	class BackupRequest : public RequestBaseManaged
	{
	public:
		DirNameManaged dirName;

#if SCE_PROSPERO_SDK_VERSION < 0x13000000u
		void CopyTo(SceSaveDataBackup &destination, SceSaveDataDirName& sceDirName);
#endif
	};

	class Backups
	{
	public:

#if SCE_PROSPERO_SDK_VERSION < 0x13000000u
		static void Backup(BackupRequest* managedRequest, APIResult* result);
#endif
	};
}

#endif	//_BACKUP_H

