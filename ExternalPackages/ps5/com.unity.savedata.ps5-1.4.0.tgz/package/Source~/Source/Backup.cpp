
#include "Backup.h"


namespace SaveData
{
	PRX_EXPORT void PrxSaveDataBackup(BackupRequest* managedRequest, APIResult* result)
	{
#if SCE_PROSPERO_SDK_VERSION < 0x13000000u
		Backups::Backup(managedRequest, result);
#else
        //Removed in SDK 13.00
        ERROR_RESULT(result, "Backup is not supported in SDK 13.00 and later");
#endif
	}

#if SCE_PROSPERO_SDK_VERSION < 0x13000000u
	void BackupRequest::CopyTo(SceSaveDataBackup &destination, SceSaveDataDirName& sceDirName)
	{
		dirName.CopyTo(sceDirName);

		memset(&destination, 0x00, sizeof(destination));
		destination.userId = userId;
		destination.dirName = &sceDirName;
	}

	void Backups::Backup(BackupRequest* managedRequest, APIResult* result)
	{
		SceSaveDataBackup del;
		SceSaveDataDirName dirName;

		managedRequest->CopyTo(del, dirName);

		int ret = sceSaveDataBackup(&del);

		if (ret < 0)
		{
			SCE_ERROR_RESULT(result, ret);
			return;
		}

		SUCCESS_RESULT(result);
	}

#endif

}
