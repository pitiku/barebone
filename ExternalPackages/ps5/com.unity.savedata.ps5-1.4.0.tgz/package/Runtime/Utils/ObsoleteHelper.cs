using System;

namespace Unity.SaveData.PS5
{
    internal static class ObsoleteHelper
    {
        internal const string SaveDataBackupRemovalWarning = "This functionality is Deprecated in SDK 11.00 onwards and will be removed in SDK 13.00";

        internal static void ThrowIfSaveDataBackupIsRemoved()
        {
            #if UNITY_PS5
            if (UnityEngine.PS5.Utility.sdkVersion >= 0x13000000u)
            {
                throw new NotSupportedException("This functionality has been removed in SDK 13.00");
            }
            #endif
        }
    }
}
