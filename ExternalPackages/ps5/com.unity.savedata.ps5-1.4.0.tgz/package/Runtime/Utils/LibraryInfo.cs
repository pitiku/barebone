
namespace Unity.SaveData.PS5
{
    internal static class LibraryInfo
    {
        internal const string LibraryName = "SaveData";
        internal static string LibraryNameWithExtension => $"{LibraryName}.prx";
    }
}
