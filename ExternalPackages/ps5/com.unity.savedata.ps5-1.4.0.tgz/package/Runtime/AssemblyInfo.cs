using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.SaveData.PS5.Editor")]
[assembly: InternalsVisibleTo("Unity.SaveData.PS5.Tests.Editor")]
