#if UNITY_EDITOR_WIN //Building for PS5 is only supported on Windows
using System;
using System.IO;
using UnityEditor;

public static class BuildUtils
{
internal static readonly string kBuildFolderName = "Build";

    internal static string GetStagingAreaLocationFor(BuildTarget buildPlatform, string projectDir, string outputPath)
    {
        string stagingArea;

#if UNITY_2022_2_OR_NEWER
        if (buildPlatform == BuildTarget.PS5)
        {
            stagingArea = Path.Combine(projectDir, "Temp", "StagingArea", "User", "Media", "Plugins");
        }else
        {
            throw new InvalidOperationException($"Cannot get staging area for {buildPlatform}");
        }
#else
        if (buildPlatform == BuildTarget.PS5)
        {
            stagingArea = Path.Combine(projectDir, "Temp", "StagingArea", "Media", "Plugins");
        }
        else
        {
            throw new InvalidOperationException($"Cannot get staging area for {buildPlatform}");
        }
#endif

        return stagingArea;
    }

}
#endif
