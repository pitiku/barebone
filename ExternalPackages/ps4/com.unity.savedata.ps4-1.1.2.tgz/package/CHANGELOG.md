# Changelog
All notable changes the Save Data package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [1.1.2] - 2026-03-23

### Fixed
- Fixed a case where an operation could throw a managed exception but have a SUCCESS return code. Instead, an operation that fails because of a managed exception will return the error code ManagedException (0x8A000002)

## [1.1.1] - 2025-08-06

### Fixed
- Fixed Windows line-endings in Search sample files
- Fixed a bug where the native PRX would not be automatically rebuilt when updating this package.

### Changed
- Updated package signatures

## [1.1.0] - 2025-02-11

### Added
- Added property `DirNameSearchRequest.TitleId` corresponding to `SceSaveDataDirNameSearchCond.titleId`, allowing one title to search for another title's savedata.
- Added a button to the sample project to search for another title's savedatas.


## [1.0.6] - 2023-08-22

### Fixed
- Fixed a linker error that could occour on recent versions of Unity

## [1.0.5] - 2024-04-23

### Fixed
- Fixed a null reference exception that could occur when creating a build for Windows IL2CPP in 2021.3
- Fixed instructions for testing TRC R4098 in sample

## [1.0.4] - 2023-02-26

### Fixed
- Fixed a infinite build loop that could occur when an error was thrown during serialization (e.g shader compilation)

## [1.0.3] - 2023-01-18

### Fixed
   - Fixed an issue where the pacakge would invalidate the PackageCache when building and the package was added from a UMP Server
   - Fixed an issue where absoulte paths in the generated cpp would dirty source control when no cotents of the file has changed
   - Fixed an issue where compiling for PS5 when PS5 was not the selected platform would result in the package PRX (or cpp replacement) not being generated

### Changed
   - Instead of a pre-processed cpp source file generated in the package folder, the package now generates a prx in the Library/SoruceGeneratedPlugins folder which is added to the build

## [1.0.2] - 2023-10-18

### Fixed
   - Stop editor build script executing when an non-PlayStation platform is being built

## [1.0.1] - 2023-10-13

### Fixed

 - Fixed clashing GUIDs with other packages

## [1.0.0] - 2023-07-19

### Changed
- Converted legacy .unitypackage to Unity Package Manager Package
- Made Sony.PS4.SaveData.InitResult.DllVersion Obsolete because C# code in the package is not in a precompiled dll anymore
