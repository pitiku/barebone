using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.PS4.SaveData.Editor")]
[assembly: InternalsVisibleTo("Unity.PS4.SaveData.Tests.Editor")]
