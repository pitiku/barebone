
namespace Sony.PS4.SaveData
{
    internal static class LibraryInfo
    {
        internal const string LibraryName = "SaveData";
        internal static string LibraryNameWithExtension => $"{LibraryName}.prx";
    }
}
