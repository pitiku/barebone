#if UNITY_EDITOR_WIN
using System;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;

public static class BuildUtils
{
internal static readonly string kBuildFolderName = "Build";

    internal static string GetStagingAreaLocationFor(BuildTarget buildPlatform, string projectDir, string outputPath)
    {
        string stagingArea;

#if UNITY_2022_2_OR_NEWER
        if (buildPlatform == BuildTarget.PS4)
        {
            stagingArea = Path.Combine(outputPath, kBuildFolderName, "Media", "Plugins");
        }else
        {
            throw new InvalidOperationException($"Cannot get staging area for {buildPlatform}");
        }
#else
        //PS4 will auto copy the contents of Data to the media folder and if you have already created a media folder
        //(i.e. StagingArea/Media) it will throw an error, so instead just copy to data and allow the PS4 build process to
        //do the copying to Media
        if (buildPlatform == BuildTarget.PS4)
        {
            stagingArea = Path.Combine(projectDir, "Temp", "StagingArea", "Data", "Plugins");
        }
        else
        {
            throw new InvalidOperationException($"Cannot get staging area for {buildPlatform}");
        }
#endif

        return stagingArea;
    }

}
#endif
