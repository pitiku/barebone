# Changelog
All notable changes to the NpToolkit2 package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

Due to package verification, the latest version below is the unpublished version and the date is meaningless.
however, it has to be formatted properly to pass verification tests.

## [1.1.0] - 2025-12-09

### Changed
   - Following the annoucement from Sony about legacy PSN Services that will be sunset in Spring 2026 for new submissions, methods that call the to be sunset APIs have been marked as Obsolete. If you have an existing title with these serivces enabled you can add UNITY_NPTOOLKIT2_SUPPRESS_SUNSET_WARNINGS to your scripting defines to suppress the obsolete warnings. Please see https://ps4.develop.playstation.net/technotes/view/1171 for more infomation. We strongly reccomend that you migrate to the PSN Cross-Gen SDK.

## [1.0.8] - 2025-08-06

### Changed
- Updated package signatures

### Fixed
- Fixed a bug where the native PRX could fail to recompile when updating this package.

## [1.0.7] - 2025-02-24

### Changed
   - Added the OriginalPrice, UpsellPlusPrice & IsPlusPrice fields to the SKUInfo class 

## [1.0.6] - 2024-08-22

### Fixed
	- Fixed a linker error that could occour on recent versions of Unity

## [1.0.5] - 2023-04-23

### Fixed
   - Fixed a null reference exception that could occur when creating a build for Windows IL2CPP in 2021.3

## [1.0.4] - 2024-02-26

### Fixed
   - Fixed a infinite build loop that could occur when an error was thrown during serialization (e.g shader compilation)

### Added
   - Added the IsActive field to the ServiceEntitlement class

## [1.0.3] - 2024-01-18

### Fixed
   - Fixed an issue where the pacakge would invalidate the PackageCache when building and the package was added from a UMP Server
   - Fixed an issue where absoulte paths in the generated cpp would dirty source control when no cotents of the file has changed
   - Fixed an issue where compiling for PS5 when PS5 was not the selected platform would result in the package PRX (or cpp replacement) not being generated

### Changed
   - Instead of a pre-processed cpp source file generated in the package folder, the package now generates a prx in the Library/SoruceGeneratedPlugins folder which is added to the build

## [1.0.2] - 2023-10-18

### Fixed
   - Stop editor build script executing when an non-PlayStation platform is being built

## [1.0.1] - 2023-10-13

### Fixed
   - Fixed clashing GUIDs with other packages

## [1.0.0] - 2023-07-17
   - Converted legacy .unitypackage to Unity Package Manager Package
