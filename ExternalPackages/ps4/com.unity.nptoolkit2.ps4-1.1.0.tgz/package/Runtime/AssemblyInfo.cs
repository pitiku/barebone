using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.PS4.NpToolkit2.Editor")]
[assembly: InternalsVisibleTo("Unity.PS4.NpToolkit2.Tests.Editor")]
