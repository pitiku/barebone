
namespace Sony.NP
{
    internal static class LibraryInfo
    {
        internal const string LibraryName = "UnityNpToolkit2";
        internal static string LibraryNameWithExtension => $"{LibraryName}.prx";

        internal const bool NpTookitDeprecationMessagesAreErrors = false;
        internal const string NpToolkitDeprecationMessage =
            "This Legacy NPTookit2 API will be sunset in Spring 2026 and will not be valid for submission. Instead move to com.unity.psn.ps5 to use the Cross-Generation SDK. Add UNITY_NPTOOLKIT2_SUPPRESS_SUNSET_WARNINGS to scripting defines to disable these warnings.";
    }
}
