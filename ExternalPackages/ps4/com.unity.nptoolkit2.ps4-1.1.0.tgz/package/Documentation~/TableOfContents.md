*[About NpToolkit2](index)
*[Installing](Title)
    *[Trophies](Trophies)

> [!CAUTION]
> Several services for PS4 will be sunset in Spring 2026 for new submissions. API's that call these libraries have been marked as obsolete in the package. 
>If you have an existing title with these serivces enabled you can add UNITY_NPTOOLKIT2_SUPPRESS_SUNSET_WARNINGS to your scripting defines to suppress the obsolete warnings. 
> Please see https://ps4.develop.playstation.net/technotes/view/1171 for more infomation.