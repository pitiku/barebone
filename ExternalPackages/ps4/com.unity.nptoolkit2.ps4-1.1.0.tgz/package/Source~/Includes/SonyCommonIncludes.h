#pragma once


#define SONY_PLATFORM 1

#include <np_toolkit2.h>

namespace NpToolkit2 = sce::Toolkit::NP::V2;

//	COMPONENT CAPABILITIES DEFINED HERE
#define	NP_HAS_ERROR_CODES		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_RANKING			(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_BANDWIDTH		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_FRIENDS_LIST		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_ONLINE_PRESENCE	(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_TROPHIES			(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )	//	Already exists on PS3 and must be removed before we can let NPToolkit take on responsibilities	
#define	NP_HAS_MATCHING			(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_WORD_FILTER		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_MESSAGING		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_TUSTSS			(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_COMMERCE			(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_NP_DIALOGS		(SN_TARGET_PSP2 || __ORBIS__ )	//	Does not exist on PS3
#define NP_HAS_NP_FACEBOOK		(SN_TARGET_PS3 || __ORBIS__  ) // Was also supported on PSP2 but removed in SDK 3.570
#define NP_HAS_TWITTER			0	// Was only supported on PSP2 but removed in SDK 3.570
#define	NP_HAS_NEAR				(SN_TARGET_PSP2)
#define NP_HAS_NP_COMMERCE		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__  )
#define	NP_HAS_TICKETING		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__)
#define NP_HAS_NP_REQUESTS		(__ORBIS__)

#define PRX_EXPORT extern "C" __declspec (dllexport)
#define	DO_EXPORT( _type, _func ) PRX_EXPORT _type _func

// this value is not limited on ps4 ... for compatability i'll set it to the vita value
#define SCE_NP_BASIC_IN_GAME_MESSAGE_SIZE_MAX (512)

// standard results for module startup
#define SCE_KERNEL_START_SUCCESS		(0)
#define SCE_KERNEL_START_NO_RESIDENT	(1)
#define SCE_KERNEL_START_FAILED			(2)

#include <np_profile_dialog.h>
#include <np_friendlist_dialog.h>

#if (SCE_ORBIS_SDK_VERSION>0x03500000u) && (SCE_ORBIS_SDK_VERSION<0x08000000u)
#include <np/np_play_together.h>
#endif

// TODO:

