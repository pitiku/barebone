
#include "Messaging.h"

#include "Core.h"

namespace NPT
{
	DO_EXPORT( int, PrxSendInGameMessage ) (SendInGameMessageManaged* managedRequest, APIResult* result)
	{
		return Messaging::SendInGameMessage(managedRequest, result);
	}

	void SendInGameMessageManaged::CopyTo(NpToolkit2::Messaging::Request::SendInGameMessage &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.message.dataSize = messageSize;
		memcpy_s(destination.message.data, SCE_NP_IN_GAME_MESSAGE_DATA_SIZE_MAX, message, messageSize);

		destination.recipientId = recipientId;
		destination.recipientPlatformType = recipientPlatformType;
	}

	int Messaging::SendInGameMessage(SendInGameMessageManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Messaging::Request::SendInGameMessage nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Messaging::sendInGameMessage(nptRequest, nptResponse);

		if (ret < 0)
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	// Notification
	void Messaging::MarshalNewInGameMessage(NptNewInGameMessageResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::NewInGameMessageBegin);

		const NptNewInGameMessage* newInGameMessage = response->get();

		buffer.WriteData(newInGameMessage->message.data, newInGameMessage->message.dataSize);

		Core::WriteToBuffer(newInGameMessage->sender, buffer);
		Core::WriteToBuffer(newInGameMessage->recipient, buffer);

		buffer.WriteUInt32((UInt32)newInGameMessage->senderPlatformType);
		buffer.WriteUInt32((UInt32)newInGameMessage->recipientPlatformType);

		buffer.WriteMarker(BufferIntegrityChecks::NewInGameMessageEnd);

		SUCCESS_RESULT(result);
	}

	void Messaging::HandleGameCustomDataEvent(SceNpGameCustomDataEventParam* eventParam)
	{
		MemoryBuffer& buffer = MemoryBuffer::GetNextFreeBuffer();
		buffer.StartResponseWrite();

		buffer.WriteMarker(BufferIntegrityChecks::GameCustomDataEventBegin);

		buffer.WriteUInt64(eventParam->itemId);
		Core::WriteToBuffer(eventParam->onlineId, buffer);
		buffer.WriteInt32(eventParam->userId);

		buffer.WriteMarker(BufferIntegrityChecks::GameCustomDataEventEnd);

		buffer.FinishResponseWrite();

		CompletedAsyncEvents::AddCustomNotification(FunctionTypeExtended::notificationGameCustomDataEvent, buffer);
	}

}
