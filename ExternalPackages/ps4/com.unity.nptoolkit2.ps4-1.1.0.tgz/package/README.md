PS4 API to use PlayStation Network features.
