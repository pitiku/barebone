﻿using UnityEngine;
using System.Collections;

#if UNITY_PS4

namespace NpToolkit2Sample
{

public class Notifications : MonoBehaviour
{
	void OnEnable()
	{

	}
	void OnDisable()
	{

	}

}

}
#endif
