﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

#if UNITY_PS4

namespace NpToolkit2Sample
{
public class SonyNpMessaging : IScreen
{
    MenuLayout m_MenuMessaging;

    Sony.NP.Messaging.GameDataMessageImage thumbnailImage = new Sony.NP.Messaging.GameDataMessageImage();

    bool hasCurrentMsg = false;
    UInt64 currentGameMsgId = 0;
    bool currentMsgHasAttachment = false;

    public SonyNpMessaging()
    {
        Initialize();
    }

    public MenuLayout GetMenu()
    {
        return m_MenuMessaging;
    }

    public void OnEnter()
    {
    }

    public void OnExit()
    {
    }

    public void Process(MenuStack stack)
    {
        MenuUserProfiles(stack);
    }

    public void SetCurrentMessage(UInt64 gameMsgId, bool msgHasAttachment)
    {
        //OnScreenLog.AddWarning("Set Current Msg : " + gameMsgId + " : Has Attachment = " + msgHasAttachment);
        hasCurrentMsg = true;
        currentGameMsgId = gameMsgId;
        currentMsgHasAttachment = msgHasAttachment;
    }

    public void ClearCurrentMessage()
    {
        hasCurrentMsg = false;
    }

    public void Initialize()
    {
        m_MenuMessaging = new MenuLayout(this, 450, 20);

        // Must define an image for the message otherwise it can't be created.
        // Also streamingAssetsPath needs to be called on the main thread. 
        thumbnailImage.ImgPath = Application.streamingAssetsPath + "/PS4SessionImage.jpg";
    }

    public void MenuUserProfiles(MenuStack menuStack)
    {
        m_MenuMessaging.Update();

        if (m_MenuMessaging.AddItem("Send In-Game Message", "Send an in-game message."))
        {
            SendInGameMessage();
        }

        if (m_MenuMessaging.AddBackIndex("Back"))
        {
            menuStack.PopMenu();
        }
    }

    public byte[] GenerateRandomGameData(int size)
    {
        System.Random rand = new System.Random();

        byte[] gameData = new byte[size];

        rand.NextBytes(gameData);

        return gameData;
    }

    public void OutputData(byte[] data)
    {
        string output = "";
        string outputLine = "";
        for (int i = 0; i < data.Length; i++)
        {
            outputLine += data[i] + ", ";

            if (outputLine.Length > 160)
            {
                output += outputLine + "\n      ";
                outputLine = "";
            }
        }

        output += outputLine;

        OnScreenLog.Add(output, true);
        OnScreenLog.AddNewLine();
    }


    public void SendInGameMessage()
    {
        try
        {
            Sony.NP.Messaging.SendInGameMessageRequest request = new Sony.NP.Messaging.SendInGameMessageRequest();

            request.UserId = User.GetActiveUserId;
            request.Message = GenerateRandomGameData(32);

            OnScreenLog.Add("Random Data to send:");
            OutputData(request.Message);

            request.RecipientPlatformType = Sony.NP.Core.PlatformType.ps4;

            // Send message to the active user.
            request.RecipientId = SonyNpUserProfiles.GetLocalAccountId(User.GetActiveUserId);

            Sony.NP.Core.EmptyResponse response = new Sony.NP.Core.EmptyResponse();

            int requestId = Sony.NP.Messaging.SendInGameMessage(request, response);
            OnScreenLog.Add("SendInGameMessage Async : Request Id = " + requestId);
        }
        catch (Sony.NP.NpToolkitException e)
        {
            OnScreenLog.AddError("Exception : " + e.ExtendedMessage);
        }
    }

    public void OnAsyncEvent(Sony.NP.NpCallbackEvent callbackEvent)
    {
        if (callbackEvent.Service == Sony.NP.ServiceTypes.Messaging)
        {
            switch (callbackEvent.ApiCalled)
            {
                case Sony.NP.FunctionTypes.MessagingSendInGameMessage:
                    OutputSendInGameMessage(callbackEvent.Response as Sony.NP.Core.EmptyResponse);
                    break;
                case Sony.NP.FunctionTypes.MessagingDisplayReceivedGameDataMessagesDialog:
                    OutputDisplayReceivedGameDataMessagesDialog(callbackEvent.Response as Sony.NP.Core.EmptyResponse);
                    break;
                case Sony.NP.FunctionTypes.MessagingSendGameDataMessage:
                    OutputSendGameDataMessage(callbackEvent.Response as Sony.NP.Core.EmptyResponse);
                    break;
                case Sony.NP.FunctionTypes.MessagingConsumeGameDataMessage:
                    OutputConsumeGameDataMessage(callbackEvent.Response as Sony.NP.Core.EmptyResponse);
                    break;
                default:
                    break;
            }
        }

        // Notifications
        if (callbackEvent.Service == Sony.NP.ServiceTypes.Notification)
        {
            switch (callbackEvent.ApiCalled)
            {
                case Sony.NP.FunctionTypes.NotificationGameCustomDataEvent:
                    {
                        Sony.NP.Messaging.GameCustomDataEventResponse gameCustomDataEventResponse = (Sony.NP.Messaging.GameCustomDataEventResponse)callbackEvent.Response;
                        
                        if ( gameCustomDataEventResponse.IsErrorCode == false)
                        {
                            // It's not possible to tell from the system event if the message has an attachment.
                            SetCurrentMessage(gameCustomDataEventResponse.ItemId, false);
                        }
                    }
                    break;
            }
        }
    }

    private void OutputSendInGameMessage(Sony.NP.Core.EmptyResponse response)
    {
        if (response == null) return;

        OnScreenLog.Add("SendInGameMessage Empty Response");

        if (response.Locked == false)
        {
        }
    }

    private void OutputDisplayReceivedGameDataMessagesDialog(Sony.NP.Core.EmptyResponse response)
    {
        if (response == null) return;

        OnScreenLog.Add("DisplayReceivedGameDataMessagesDialog Empty Response");

        if (response.Locked == false)
        {
        }
    }

    private void OutputSendGameDataMessage(Sony.NP.Core.EmptyResponse response)
    {
        if (response == null) return;

        OnScreenLog.Add("SendGameDataMessage Empty Response");

        if (response.Locked == false)
        {
        }
    }

    private void OutputConsumeGameDataMessage(Sony.NP.Core.EmptyResponse response)
    {
        if (response == null) return;

        OnScreenLog.Add("ConsumeGameDataMessage Empty Response");

        if (response.Locked == false)
        {
        }

        ClearCurrentMessage();
    }
    
}
}
#endif
