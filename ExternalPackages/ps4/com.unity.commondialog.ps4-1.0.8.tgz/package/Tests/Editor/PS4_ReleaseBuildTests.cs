using UnityEditor;
using UnityEditor.TestTools;

[RequirePlatformSupport(BuildTarget.PS4)]
public class PS4_ReleaseBuildTests : BuildTestExpectedPlugin
{
    protected override BuildOptions GetBuildOptions()
    {
        return BuildOptions.None;
    }

    protected override (BuildTargetGroup, BuildTarget) GetBuildTarget()
    {
        return (BuildTargetGroup.PS4, BuildTarget.PS4);
    }
}
