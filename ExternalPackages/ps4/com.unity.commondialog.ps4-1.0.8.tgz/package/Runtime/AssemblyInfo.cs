using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.CommonDialog.PS4.Editor")]
[assembly: InternalsVisibleTo("com.unity.commondialog.ps4.tests.editor")]
