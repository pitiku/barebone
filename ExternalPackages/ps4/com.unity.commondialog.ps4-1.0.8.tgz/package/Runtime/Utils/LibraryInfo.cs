
namespace Sony.PS4.Dialog
{
    internal static class LibraryInfo
    {
        internal const string LibraryName = "CommonDialog";
        internal static string LibraryNameWithExtension => $"{LibraryName}.prx";
    }
}
