using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonDialogSample
{

public interface IScreen
{
	void Process(MenuStack stack);
	void OnEnter();
	void OnExit();
}
}