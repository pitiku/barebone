using UnityEngine;
using UnityEditor;
using System.IO;
using System;

public class SetCommonDialogPlatformOptionsPS4
{
	static string SearchForFile(string path, string findFilename)
	{
		var files = Directory.EnumerateFiles(path, "*.*", SearchOption.AllDirectories);
		foreach (var file in files)
		{
			if (Path.GetFileNameWithoutExtension(file) == findFilename)
				return file;
		}
		
		return "";
	}

	// Replace whatever Input Manager you currently have with one to work with the CommonDialog Sample
	[MenuItem("SCE Publishing Utils/Set Input Manager PS4 for CommonDialog sample")]
	static void ReplaceInputManager()
	{

		// This is the InputManager asset that comes with the example project. Note that to avoid an import error, the '.asset' file extension has been removed
		string sourceFile = SearchForFile(Application.dataPath, "InputManager");

		// This is the InputManager in your ProjectSettings folder
		string targetFile = Application.dataPath;
		targetFile = targetFile.Replace("/Assets", "/ProjectSettings/InputManager.asset");

		// Replace the ProjectSettings file with the new one, and trigger a refresh so the Editor sees it
		FileUtil.ReplaceFile(sourceFile, targetFile);
		AssetDatabase.Refresh();

		Debug.Log("InputManager replaced! " + sourceFile + " -> " + targetFile);
	}
}
