# Changelog
All notable changes to the Common Dialog package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

Due to package verification, the latest version below is the unpublished version and the date is meaningless.
however, it has to be formatted properly to pass verification tests.

## [1.0.8] - 2025-08-06

### Changed
- Updated package signatures

### Fixed
- Fixed a bug where the native PRX could fail to recompile after upgrading this package.

## [1.0.7] - 2023-08-22

### Fixed
- Fixed a linker error that could occour on recent versions of Unity

## [1.0.6] - 2023-04-23

### Fixed
- Fixed a null reference exception that could occur when creating a build for Windows IL2CPP in 2021.3

## [1.0.5] - 2023-02-26

### Fixed
- Fixed a infinite build loop that could occur when an error was thrown during serialization (e.g shader compilation)

## [1.0.4] - 2023-01-18

### Fixed
   - Fixed an issue where the pacakge would invalidate the PackageCache when building and the package was added from a UMP Server
   - Fixed an issue where absoulte paths in the generated cpp would dirty source control when no cotents of the file has changed
   - Fixed an issue where compiling for PS5 when PS5 was not the selected platform would result in the package PRX (or cpp replacement) not being generated

### Changed
   - Instead of a pre-processed cpp source file generated in the package folder, the package now generates a prx in the Library/SoruceGeneratedPlugins folder which is added to the build

## [1.0.3] - 2023-10-25

### Fixed
   - Remove some managed code to native functions that never existed.

## [1.0.2] - 2023-10-18

### Fixed
   - Stop editor build script executing when an non-PlayStation platform is being built

## [1.0.1] - 2023-10-13

### Fixed

 - Fixed clashing GUIDs with other packages

## [1.0.0] - 2023-07-21

### Changed

 - Converted .unitypackage to Unity Package Manager Package


 






