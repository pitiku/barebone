PS4 API to use Common Dialog features.
