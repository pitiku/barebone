using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.InputSystem.PS4.Tests")]
