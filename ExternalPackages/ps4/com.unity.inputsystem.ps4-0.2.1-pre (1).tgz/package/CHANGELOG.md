# Changelog
All notable changes to the input system package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

Due to package verification, the latest version below is the unpublished version and the date is meaningless.
however, it has to be formatted properly to pass verification tests.

## [0.1.0-preview] - 2019-9-2

First release from develop branch.

## [0.1.1-preview] - 2019-10-29

Updated package dependencies to use latest `com.unity.inputsystem` package version 1.0.0-preview.1

## [0.1.2-preview] - 2020-05-13

Added Primary and Secondary usages for PS4 Move controllers

## [0.1.3-preview] - 2021-01-18

Minor fix - corrected bits for d-pad.

## [0.1.4-pre] - 2021-11-15

Package is now signed. Updated to new package lifecycle naming convention.

## [0.1.5-preview] - 2023-07-11

Set Input System runtime to run in the background. This fixes issues where the InputSystem would not receive input events when the game was not in focus.
Update Input System dependency to version 1.6.1

## [0.1.6-preview] - 2023-07-11

Added Sample on how to use Dualshock speific features

## [0.1.7-preview] - 2024-03-15

### Fixed
Fixed the Acceleration, Orientation and Angular Velocity values of a Dualshock Controller on PS5 being reported in the SDK's Right-Handed Coordinates Space rather than Unity's Left-Handed Coordinates Space

## [0.1.8-preview] - 2024-05-09

### Fixed
Guarantee that Input Processors are initalised before devices to avoid a InvalidOperationException that could occour in some scenarios

## [0.2.0-preview] - 2024-11-27

### Added 
Added in Unity 6000.1.0a7 or later, the following properties on PS4, previously only avalible via PS4Input. functions: touchPadInformation, stickInfo, deviceClass, connectionType. Pressing both thumbsticks together in the Input System Sample will show the infomation listed above.

Added in Unity 6000.1.0a7 or later, the following functions on PS4, previously only avalible via PS4Input. functions: SetTiltCorrectionState, SetMotionSensorState, SetAngularVelocityDeadbandState

## [0.2.1-preview] - 2025-09-30

### Changed
Updated package signatures
