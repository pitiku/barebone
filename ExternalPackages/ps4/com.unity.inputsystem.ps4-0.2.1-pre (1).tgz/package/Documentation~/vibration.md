# Vibration

The PS4 DualShock®4 wireless controller supports vibration feedback through two motors inside of the controller. These motors are used to provide physical feedback to the player during gameplay. The two internal motors differ in size, one large and one small, and can be controlled independently to create a variety of vibration effects.

## Set vibration speed

Use [`SetMotorSpeeds`](xref:UnityEngine.InputSystem.PS4.DualShockGamepadPS4.SetMotorSpeeds(System.Single,System.Single)) to set the vibration speed of the large and small motors. Set a low frequency value to target the large motor, and a high frequency value to target the small motor. You can use normalized values between `0` and `1`, where `0` turns the motor off and `1` sets the maximum rotation speed.

For more information, refer to [ScePadVibrationParam](https://ps4.develop.playstation.net/resources/documents/SDK/latest/Pad-Reference/0016.html) (PlayStation®4 DevNet).

## Additional resources

* [SetMotorSpeeds scripting reference](xref:UnityEngine.InputSystem.PS4.DualShockGamepadPS4.SetMotorSpeeds(System.Single,System.Single))
* [ScePadVibrationParam](https://ps4.develop.playstation.net/resources/documents/SDK/latest/Pad-Reference/0016.html) (PlayStation®4 DevNet)