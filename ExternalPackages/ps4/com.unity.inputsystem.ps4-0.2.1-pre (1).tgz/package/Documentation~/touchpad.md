# Touchpad

The DualShock®4 wireless controller has a capacitive touchpad that a player can interact with in your title. The touchpad can detect a maximum of two points of contact at any one time and can also be used as a button.

For more information on using the touchpad, refer to [Using the Touch Pad](hhttps://ps4.develop.playstation.net/resources/documents/SDK/latest/Pad-Overview/0004.html#__document_toc_00000011) (PlayStation®4 DevNet).

## Retrieving touchpad data

The touchpad uses a coordinate system to track any touches on the surface. This requires the touchpad to have a set resolution and pixel density. For the DualShock®4 wireless controller, the resolution is defined as 1920 × 942, and the pixel density as 44.86 dots/mm. As other controllers can be used with the PlayStation 4 (PS4), it’s recommended to use [`TouchPadInformation`](xref:UnityEngine.InputSystem.PS4.DualShockGamepadPS4.touchPadInformation) to retrieve the resolution and pixel density of each connected controller.

> [!NOTE] 
> `TouchPadInformation` is available only in Unity 6000.1 and later.

The value of a touch on a touchpad touch is normalized in the range of 0 to 1, based on the expected resolution of 1920 × 942. When working with controllers that have different touchpad resolutions, multiply these values by the difference in resolutions to get the correct value. If the distance between two points is less than 1 cm, the two points might be recognized as one point.

> [!NOTE]
> (&minus;1,&minus;1) is the value supplied from the pad when the touchpad doesn’t have a valid touch position.

## Additional resources

* [Using the Touch Pad](https://ps4.develop.playstation.net/resources/documents/SDK/latest/Pad-Overview/0004.html#__document_toc_00000011) (PlayStation®4 DevNet)




