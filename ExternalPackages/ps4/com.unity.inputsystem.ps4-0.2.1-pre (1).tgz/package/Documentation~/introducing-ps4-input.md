# Introducing the PS4 Input System package

The PS4 Input System package provides support for the unique features of the DualShock®4 controller for PlayStation®4 (PS4). The package opens access to the following DualShock®4 features:

* Vibration
* Touchpad
* Motion sensor
* Light bar

If the [Input System](https://docs.unity3d.com/Packages/com.unity.inputsystem@latest) package is in use within your project, you must use the PS4 Input System package to access the features of the DualShock®4 controller on PS4. 

> [!NOTE]
> The Unity Input System package will automatically install as part of the PS4 input package installation process.

The package contains a sample scene titled **Multi Controller PS4 Input Samples** that gives examples of how to interact with the DualShock®4 features in the package. For more information, refer to [Use the Sample project](sample-project.md).

To get started, follow the [Get started with the PS4 Input System package](getting-started.md) guide and information on the [features of the DualShock®4 Wireless Controller](dualshock-features.md).

## Additional resources

* [Getting started with the PS4 Input System package](getting-started.md)
* [Use the DualShock®4 Wireless Controller features](dualshock-features.md)
* [Use the sample project](sample-project.md)

