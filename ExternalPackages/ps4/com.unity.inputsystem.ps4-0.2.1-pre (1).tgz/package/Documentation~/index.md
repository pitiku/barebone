# PS4 Input System package

The PlayStation®4 (PS4) Input System package provides input feature and Unity Editor support for the DualShock®4 Wireless Controller.

|**Topic**|**Description**|
|---|---|
|[**Introducing the PS4 Input System package**](introducing-PS4-input.md)|Provides an overview of the PS4 Input System package.|
|[**Getting started with the PS4 Input System package**](getting-started.md)|Provides information on how to set up the PS4 Input System package.|
|[**Use the DualShock®4 Wireless Controller features**](dualshock-features.md)|Provides information on the features of the DualShock®4 controller.|
|[**Use the sample project**](sample-project.md)|Provides information on how to use the sample project.|

## Additional resources

* [Input System](https://docs.unity3d.com/Packages/com.unity.inputsystem@latest)
* [Pad Library Overview (PlayStation®4 DevNet)](https://ps4.develop.playstation.net/resources/documents/SDK/latest/Pad-Overview/__toc.html)