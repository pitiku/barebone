# Light bar

The DualShock®4 wireless controller has a light bar on the rear of the device. You can set the color of the light bar to any RGB color value, and control when the light bar activates.

For more information, refer to [Using the Light Bar Feature](https://ps4.develop.playstation.net/resources/documents/SDK/latest/Pad-Overview/0007.html#__document_toc_00000019) (PlayStation®4 DevNet).

## Update the light bar color

To update the light bar color, use the following information:

* Use [`SetLightBarColor(Color)`](xref:UnityEngine.InputSystem.PS4.DualShockGamepadPS4.SetLightBarColor(UnityEngine.Color)) to set the color of the light bar for the chosen controller. 
* Use [`ResetLightBarColor()`](xref:UnityEngine.InputSystem.PS4.DualShockGamepadPS4.ResetLightBarColor) to reset the light bar and turn it off.

## Additional resources

* [Using the Light Bar Feature](https://ps4.develop.playstation.net/resources/documents/SDK/latest/Pad-Overview/0007.html#__document_toc_00000019) (PlayStation®4 DevNet)