# Use the sample scene

The PS4 Input system package includes a sample scene to help you understand the features covered in this documentation. 

## Import the sample

To import the sample, use the following steps:

1) Navigate to **Window** > **Package Manager**.
1) Select the **Input System PS4** package from the list of packages in the project.
1) Click **Samples** to open the sample import section of the window.
1) Click **Import** next to the **Multi Controller PS4 Input Samples** sample.

## Sample scene features

The sample scene displays user input for up to 4 connected DualShock®4 controllers. In Play mode, interacting with a connected controller's buttons, sticks, and triggers will cause sections of the controller image to light up in relation to what element was interacted with. 

To do this, use the following steps:

1) Select a **PS_Gamepad_\<number\>** GameObject from the Hierarchy window. 
2) In the Inspector window, in the **Game Pad (Script)** section, update and experiment with the different settings and sliders available to you. 

The most relevant parameters to change are as follows:

* **Gamepad Haptics (Script)** - Each Trigger (Left/Right) can be changed independently.
    * **Audio Clip** - You can change the audio clip that's played when the pressing the trigger.
    * **Touchpad Audio** - You can change the audio clips played when pressing on the touchpad.

### Info overlay

The sample scene includes an info overlay that displays information about the connected controllers. To access this information, with a connecetd controller press both sticks. The overlay will display the following information:

* [touchPadInformation]()
* [stickInfo]()
* [deviceClass]()
* [connectionType]()

## Additional resources

* [Use the DualShock®4 Wireless Controller features](dualshock-features.md)




