# Use the DualShock®4® Wireless Controller features

Use the following pages to understand and implement the features of the DualShock®4 Wireless Controller using the PS4 Input System package.


|**Topic**|**Description**|
|---|---|
|[**Vibration**](vibration.md)|Add physical feedback to your title using vibration.|
|[**Touchpad**](touchpad.md)|Understand how to access and use the DualShock®4 touchpad.|
|[**Motion sensors**](motion-sensors.md)|Access data from the in-built accelerometer and gyroscope.|
|[**Light bar**](light-bar.md)|Update and use the DualShock®4 light bar.|
|[**Controller information**](controller-information.md)|Access information about each active controller.|


