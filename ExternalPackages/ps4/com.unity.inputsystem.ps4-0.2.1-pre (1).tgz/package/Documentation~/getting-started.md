# Get started with the PS4 Input System package

Details initial set up steps for working with the PS4 Input System package.

## Install the package

To access the features of the PS4 Input System package, install the package using the following steps:
1) Download the package .tgz file from [Unity for PlayStation 4 Downloads](https://ps4.develop.playstation.net/forums/thread/227324/)(PlayStaion 4 DevNet).
1) Install the .tgz file using the steps in the [Package Manager documentation](https://docs.unity3d.com/Manual/upm-ui-tarball.html). 
    * The package will also install the [Unity Input System](https://docs.unity3d.com/Packages/com.unity.inputsystem@latest) package as a dependency.

## Enable the Input System

You must enable the new input system to allow the PS4 Input System package to operate correctly. To do this, use the following steps:

1) From the Unity menu, navigate to **Edit** > **Project Settings** > **Player** > **Configuration**.
1) Set **Active Input Handling** to **Input System Package (New)** or **Both**.

## Install the sample

It’s recommended to install the provided samples to explore the features available to you. For more information about the included sample, refer to [Use the sample project](sample-project.md).

## Additional resources

* [Use the DualShock®4 Wireless Controller features](DualShock-features.md)
* [Use the sample project](sample-project.md)
