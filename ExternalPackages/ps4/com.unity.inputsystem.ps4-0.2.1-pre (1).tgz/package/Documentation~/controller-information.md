# Controller information

Use the following APIs to return specific information about the connected controllers.

> [!NOTE] 
> The following APIs are available only in Unity 6000.1 and later.

## Connection type

Use [`ConnectionType`](xref:UnityEngine.InputSystem.PS4.LowLevel.ConnectionType) to check the connection status of the controller.

|**Connection type**|**Description**|
|---|---|
|**Local**|Indicates that the controller is connected over USB or a Bluetooth connection.|

## Device class

Use [`DeviceClass`](xref:UnityEngine.InputSystem.PS4.LowLevel.DeviceClass) to identify the type of controller connected to the PS4. For more information on the supported controller types, refer to [Using Special Controllers](https://ps4.develop.playstation.net/resources/documents/SDK/latest/Pad-Overview/0009.html) (PlayStation®4 DevNet).

The available types and values are as follows:

|**Device type**|**Value**|
|---|---|
|**Standard**|`0`|
|**Guitar**|`1`|
|**Drum**|`2`|
|**DjTurntable**|`3`|
|**Dancemat**|`4`|
|**Navigation**|`5`|
|**SteeringWheel**|`6`|
|**Stick**|`7`|
|**FlightStick**|`8`|
|**Gun**|`9`|

## Stick information

Use [`StickInformation`](xref:UnityEngine.InputSystem.PS4.LowLevel.StickInfo) to return information about the analog sticks dead zones. For more information, refer to [ScePadStickInformation](https://ps4.develop.playstation.net/resources/documents/SDK/latest/Pad-Reference/0012.html) (PlayStation®4 DevNet).

> [!NOTE]
> These values are set by the user in the system software if using a DualSense Edge controller.

## Touchpad information

Use [`TouchPadInformation`](xref:UnityEngine.InputSystem.PS4.LowLevel.TouchPadInformation) to return the resolution and pixel density of the connected controllers touchpad. For more information on using this data, refer to [Touchpad](touchpad.md).

## Additional resources

* [ScePadControllerInformation](https://ps4.develop.playstation.net/resources/documents/SDK/12.000/Pad-Reference/0004.html)(PlayStation®4 DevNet)



